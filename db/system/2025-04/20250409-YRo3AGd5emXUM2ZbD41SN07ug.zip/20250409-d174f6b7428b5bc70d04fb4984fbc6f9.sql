DROP TABLE cmf_admin_menu;

CREATE TABLE `cmf_admin_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父菜单id',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '菜单类型;1:有界面可访问菜单,2:无界面可访问菜单,0:只作为菜单',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态;1:显示,0:不显示',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `app` varchar(40) NOT NULL DEFAULT '' COMMENT '应用名',
  `controller` varchar(30) NOT NULL DEFAULT '' COMMENT '控制器名',
  `action` varchar(30) NOT NULL DEFAULT '' COMMENT '操作名称',
  `param` varchar(50) NOT NULL DEFAULT '' COMMENT '额外参数',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '菜单名称',
  `icon` varchar(20) NOT NULL DEFAULT '' COMMENT '菜单图标',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `parent_id` (`parent_id`) USING BTREE,
  KEY `controller` (`controller`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=249 DEFAULT CHARSET=utf8mb4 COMMENT='后台菜单表';

INSERT INTO cmf_admin_menu VALUES("2","1","1","0","1000","admin","Hook","index","","钩子管理","","钩子管理");
INSERT INTO cmf_admin_menu VALUES("3","2","1","0","1000","admin","Hook","plugins","","钩子插件管理","","钩子插件管理");
INSERT INTO cmf_admin_menu VALUES("4","2","2","0","1000","admin","Hook","pluginListOrder","","钩子插件排序","","钩子插件排序");
INSERT INTO cmf_admin_menu VALUES("5","2","1","0","1000","admin","Hook","sync","","同步钩子","","同步钩子");
INSERT INTO cmf_admin_menu VALUES("6","0","0","1","10","admin","Setting","default","","设置","cogs","系统设置入口");
INSERT INTO cmf_admin_menu VALUES("8","248","1","0","1000","admin","Link","add","","添加友情链接","","添加友情链接");
INSERT INTO cmf_admin_menu VALUES("9","248","2","0","1000","admin","Link","addPost","","添加友情链接提交保存","","添加友情链接提交保存");
INSERT INTO cmf_admin_menu VALUES("10","248","1","0","1000","admin","Link","edit","","编辑友情链接","","编辑友情链接");
INSERT INTO cmf_admin_menu VALUES("11","248","2","0","1000","admin","Link","editPost","","编辑友情链接提交保存","","编辑友情链接提交保存");
INSERT INTO cmf_admin_menu VALUES("12","248","2","0","1000","admin","Link","delete","","删除友情链接","","删除友情链接");
INSERT INTO cmf_admin_menu VALUES("13","248","2","0","1000","admin","Link","listOrder","","友情链接排序","","友情链接排序");
INSERT INTO cmf_admin_menu VALUES("14","248","2","0","1000","admin","Link","toggle","","友情链接显示隐藏","","友情链接显示隐藏");
INSERT INTO cmf_admin_menu VALUES("16","15","2","0","1000","admin","Mailer","indexPost","","邮箱配置提交保存","","邮箱配置提交保存");
INSERT INTO cmf_admin_menu VALUES("17","15","1","0","1000","admin","Mailer","template","","邮件模板","","邮件模板");
INSERT INTO cmf_admin_menu VALUES("18","15","2","0","1000","admin","Mailer","templatePost","","邮件模板提交","","邮件模板提交");
INSERT INTO cmf_admin_menu VALUES("19","15","1","0","1000","admin","Mailer","test","","邮件发送测试","","邮件发送测试");
INSERT INTO cmf_admin_menu VALUES("21","20","1","0","1000","admin","Menu","lists","","所有菜单","","后台所有菜单列表");
INSERT INTO cmf_admin_menu VALUES("22","20","1","0","1000","admin","Menu","add","","后台菜单添加","","后台菜单添加");
INSERT INTO cmf_admin_menu VALUES("23","20","2","0","1000","admin","Menu","addPost","","后台菜单添加提交保存","","后台菜单添加提交保存");
INSERT INTO cmf_admin_menu VALUES("24","20","1","0","1000","admin","Menu","edit","","后台菜单编辑","","后台菜单编辑");
INSERT INTO cmf_admin_menu VALUES("25","20","2","0","1000","admin","Menu","editPost","","后台菜单编辑提交保存","","后台菜单编辑提交保存");
INSERT INTO cmf_admin_menu VALUES("26","20","2","0","1000","admin","Menu","delete","","后台菜单删除","","后台菜单删除");
INSERT INTO cmf_admin_menu VALUES("27","20","2","0","1000","admin","Menu","listOrder","","后台菜单排序","","后台菜单排序");
INSERT INTO cmf_admin_menu VALUES("28","20","1","0","1000","admin","Menu","getActions","","导入新后台菜单","","导入新后台菜单");
INSERT INTO cmf_admin_menu VALUES("30","29","1","0","1000","admin","Nav","add","","添加导航","","添加导航");
INSERT INTO cmf_admin_menu VALUES("31","29","2","0","1000","admin","Nav","addPost","","添加导航提交保存","","添加导航提交保存");
INSERT INTO cmf_admin_menu VALUES("32","29","1","0","1000","admin","Nav","edit","","编辑导航","","编辑导航");
INSERT INTO cmf_admin_menu VALUES("33","29","2","0","1000","admin","Nav","editPost","","编辑导航提交保存","","编辑导航提交保存");
INSERT INTO cmf_admin_menu VALUES("34","29","2","0","1000","admin","Nav","delete","","删除导航","","删除导航");
INSERT INTO cmf_admin_menu VALUES("35","29","1","0","1000","admin","NavMenu","index","","导航菜单","","导航菜单");
INSERT INTO cmf_admin_menu VALUES("36","35","1","0","1000","admin","NavMenu","add","","添加导航菜单","","添加导航菜单");
INSERT INTO cmf_admin_menu VALUES("37","35","2","0","1000","admin","NavMenu","addPost","","添加导航菜单提交保存","","添加导航菜单提交保存");
INSERT INTO cmf_admin_menu VALUES("38","35","1","0","1000","admin","NavMenu","edit","","编辑导航菜单","","编辑导航菜单");
INSERT INTO cmf_admin_menu VALUES("39","35","2","0","1000","admin","NavMenu","editPost","","编辑导航菜单提交保存","","编辑导航菜单提交保存");
INSERT INTO cmf_admin_menu VALUES("40","35","2","0","1000","admin","NavMenu","delete","","删除导航菜单","","删除导航菜单");
INSERT INTO cmf_admin_menu VALUES("41","35","2","0","1000","admin","NavMenu","listOrder","","导航菜单排序","","导航菜单排序");
INSERT INTO cmf_admin_menu VALUES("42","1","1","1","1000","admin","Plugin","index","","插件列表","","插件列表");
INSERT INTO cmf_admin_menu VALUES("43","42","2","0","1000","admin","Plugin","toggle","","插件启用禁用","","插件启用禁用");
INSERT INTO cmf_admin_menu VALUES("44","42","1","0","1000","admin","Plugin","setting","","插件设置","","插件设置");
INSERT INTO cmf_admin_menu VALUES("45","42","2","0","1000","admin","Plugin","settingPost","","插件设置提交","","插件设置提交");
INSERT INTO cmf_admin_menu VALUES("46","42","2","0","1000","admin","Plugin","install","","插件安装","","插件安装");
INSERT INTO cmf_admin_menu VALUES("47","42","2","0","1000","admin","Plugin","update","","插件更新","","插件更新");
INSERT INTO cmf_admin_menu VALUES("48","42","2","0","1000","admin","Plugin","uninstall","","卸载插件","","卸载插件");
INSERT INTO cmf_admin_menu VALUES("49","0","1","1","8150","admin","guanlizu","index","","管理组","users","");
INSERT INTO cmf_admin_menu VALUES("50","49","1","1","1000","admin","Rbac","index","","角色管理","","角色管理");
INSERT INTO cmf_admin_menu VALUES("51","50","1","0","1000","admin","Rbac","roleAdd","","添加角色","","添加角色");
INSERT INTO cmf_admin_menu VALUES("52","50","2","0","1000","admin","Rbac","roleAddPost","","添加角色提交","","添加角色提交");
INSERT INTO cmf_admin_menu VALUES("53","50","1","0","1000","admin","Rbac","roleEdit","","编辑角色","","编辑角色");
INSERT INTO cmf_admin_menu VALUES("54","50","2","0","1000","admin","Rbac","roleEditPost","","编辑角色提交","","编辑角色提交");
INSERT INTO cmf_admin_menu VALUES("55","50","2","0","1000","admin","Rbac","roleDelete","","删除角色","","删除角色");
INSERT INTO cmf_admin_menu VALUES("56","50","1","0","1000","admin","Rbac","authorize","","设置角色权限","","设置角色权限");
INSERT INTO cmf_admin_menu VALUES("57","50","2","0","1000","admin","Rbac","authorizePost","","角色授权提交","","角色授权提交");
INSERT INTO cmf_admin_menu VALUES("59","58","2","0","1000","admin","RecycleBin","restore","","回收站还原","","回收站还原");
INSERT INTO cmf_admin_menu VALUES("60","58","2","0","1000","admin","RecycleBin","delete","","回收站彻底删除","","回收站彻底删除");
INSERT INTO cmf_admin_menu VALUES("62","61","1","0","1000","admin","Route","add","","添加路由规则","","添加路由规则");
INSERT INTO cmf_admin_menu VALUES("63","61","2","0","1000","admin","Route","addPost","","添加路由规则提交","","添加路由规则提交");
INSERT INTO cmf_admin_menu VALUES("64","61","1","0","1000","admin","Route","edit","","路由规则编辑","","路由规则编辑");
INSERT INTO cmf_admin_menu VALUES("65","61","2","0","1000","admin","Route","editPost","","路由规则编辑提交","","路由规则编辑提交");
INSERT INTO cmf_admin_menu VALUES("66","61","2","0","1000","admin","Route","delete","","路由规则删除","","路由规则删除");
INSERT INTO cmf_admin_menu VALUES("67","61","2","0","1000","admin","Route","ban","","路由规则禁用","","路由规则禁用");
INSERT INTO cmf_admin_menu VALUES("68","61","2","0","1000","admin","Route","open","","路由规则启用","","路由规则启用");
INSERT INTO cmf_admin_menu VALUES("69","61","2","0","1000","admin","Route","listOrder","","路由规则排序","","路由规则排序");
INSERT INTO cmf_admin_menu VALUES("70","61","1","0","1000","admin","Route","select","","选择URL","","选择URL");
INSERT INTO cmf_admin_menu VALUES("72","71","2","0","1000","admin","Setting","sitePost","","网站信息设置提交","","网站信息设置提交");
INSERT INTO cmf_admin_menu VALUES("73","199","1","0","1000","admin","Setting","password","","密码修改","","密码修改");
INSERT INTO cmf_admin_menu VALUES("74","73","2","0","1000","admin","Setting","passwordPost","","密码修改提交","","密码修改提交");
INSERT INTO cmf_admin_menu VALUES("76","75","2","0","1000","admin","Setting","uploadPost","","上传设置提交","","上传设置提交");
INSERT INTO cmf_admin_menu VALUES("77","199","1","0","1000","admin","Setting","clearCache","","清除缓存","","清除缓存");
INSERT INTO cmf_admin_menu VALUES("78","6","1","1","20","admin","Slide","de","","幻灯片管理","","幻灯片管理");
INSERT INTO cmf_admin_menu VALUES("79","247","1","0","1000","admin","Slide","add","","添加幻灯片","","添加幻灯片");
INSERT INTO cmf_admin_menu VALUES("80","247","2","0","1000","admin","Slide","addPost","","添加幻灯片提交","","添加幻灯片提交");
INSERT INTO cmf_admin_menu VALUES("81","247","1","0","1000","admin","Slide","edit","","编辑幻灯片","","编辑幻灯片");
INSERT INTO cmf_admin_menu VALUES("82","247","2","0","1000","admin","Slide","editPost","","编辑幻灯片提交","","编辑幻灯片提交");
INSERT INTO cmf_admin_menu VALUES("83","247","2","0","1000","admin","Slide","delete","","删除幻灯片","","删除幻灯片");
INSERT INTO cmf_admin_menu VALUES("84","247","1","0","1000","admin","SlideItem","index","","幻灯片页面列表","","幻灯片页面列表");
INSERT INTO cmf_admin_menu VALUES("85","84","1","0","1000","admin","SlideItem","add","","幻灯片页面添加","","幻灯片页面添加");
INSERT INTO cmf_admin_menu VALUES("86","84","2","0","1000","admin","SlideItem","addPost","","幻灯片页面添加提交","","幻灯片页面添加提交");
INSERT INTO cmf_admin_menu VALUES("87","84","1","0","1000","admin","SlideItem","edit","","幻灯片页面编辑","","幻灯片页面编辑");
INSERT INTO cmf_admin_menu VALUES("88","84","2","0","1000","admin","SlideItem","editPost","","幻灯片页面编辑提交","","幻灯片页面编辑提交");
INSERT INTO cmf_admin_menu VALUES("89","84","2","0","1000","admin","SlideItem","delete","","幻灯片页面删除","","幻灯片页面删除");
INSERT INTO cmf_admin_menu VALUES("90","84","2","0","1000","admin","SlideItem","ban","","幻灯片页面隐藏","","幻灯片页面隐藏");
INSERT INTO cmf_admin_menu VALUES("91","84","2","0","1000","admin","SlideItem","cancelBan","","幻灯片页面显示","","幻灯片页面显示");
INSERT INTO cmf_admin_menu VALUES("92","84","2","0","1000","admin","SlideItem","listOrder","","幻灯片页面排序","","幻灯片页面排序");
INSERT INTO cmf_admin_menu VALUES("94","93","2","0","1000","admin","Storage","settingPost","","文件存储设置提交","","文件存储设置提交");
INSERT INTO cmf_admin_menu VALUES("96","95","1","0","1000","admin","Theme","install","","安装模板","","安装模板");
INSERT INTO cmf_admin_menu VALUES("97","95","2","0","1000","admin","Theme","uninstall","","卸载模板","","卸载模板");
INSERT INTO cmf_admin_menu VALUES("98","95","2","0","1000","admin","Theme","installTheme","","模板安装","","模板安装");
INSERT INTO cmf_admin_menu VALUES("99","95","2","0","1000","admin","Theme","update","","模板更新","","模板更新");
INSERT INTO cmf_admin_menu VALUES("100","95","2","0","1000","admin","Theme","active","","启用模板","","启用模板");
INSERT INTO cmf_admin_menu VALUES("101","95","1","0","1000","admin","Theme","files","","模板文件列表","","启用模板");
INSERT INTO cmf_admin_menu VALUES("102","95","1","0","1000","admin","Theme","fileSetting","","模板文件设置","","模板文件设置");
INSERT INTO cmf_admin_menu VALUES("103","95","1","0","1000","admin","Theme","fileArrayData","","模板文件数组数据列表","","模板文件数组数据列表");
INSERT INTO cmf_admin_menu VALUES("104","95","2","0","1000","admin","Theme","fileArrayDataEdit","","模板文件数组数据添加编辑","","模板文件数组数据添加编辑");
INSERT INTO cmf_admin_menu VALUES("105","95","2","0","1000","admin","Theme","fileArrayDataEditPost","","模板文件数组数据添加编辑提交保存","","模板文件数组数据添加编辑提交保存");
INSERT INTO cmf_admin_menu VALUES("106","95","2","0","1000","admin","Theme","fileArrayDataDelete","","模板文件数组数据删除","","模板文件数组数据删除");
INSERT INTO cmf_admin_menu VALUES("107","95","2","0","1000","admin","Theme","settingPost","","模板文件编辑提交保存","","模板文件编辑提交保存");
INSERT INTO cmf_admin_menu VALUES("108","95","1","0","1000","admin","Theme","dataSource","","模板文件设置数据源","","模板文件设置数据源");
INSERT INTO cmf_admin_menu VALUES("109","95","1","0","1000","admin","Theme","design","","模板设计","","模板设计");
INSERT INTO cmf_admin_menu VALUES("111","49","1","1","1000","admin","User","index","","管理员","","管理员管理");
INSERT INTO cmf_admin_menu VALUES("112","111","1","0","1000","admin","User","add","","管理员添加","","管理员添加");
INSERT INTO cmf_admin_menu VALUES("113","111","2","0","1000","admin","User","addPost","","管理员添加提交","","管理员添加提交");
INSERT INTO cmf_admin_menu VALUES("114","111","1","0","1000","admin","User","edit","","管理员编辑","","管理员编辑");
INSERT INTO cmf_admin_menu VALUES("115","111","2","0","1000","admin","User","editPost","","管理员编辑提交","","管理员编辑提交");
INSERT INTO cmf_admin_menu VALUES("116","111","1","0","1000","admin","User","userInfo","","个人信息","","管理员个人信息修改");
INSERT INTO cmf_admin_menu VALUES("117","111","2","0","1000","admin","User","userInfoPost","","管理员个人信息修改提交","","管理员个人信息修改提交");
INSERT INTO cmf_admin_menu VALUES("118","111","2","0","1000","admin","User","delete","","管理员删除","","管理员删除");
INSERT INTO cmf_admin_menu VALUES("119","111","2","0","1000","admin","User","ban","","停用管理员","","停用管理员");
INSERT INTO cmf_admin_menu VALUES("120","111","2","0","1000","admin","User","cancelBan","","启用管理员","","启用管理员");
INSERT INTO cmf_admin_menu VALUES("121","199","1","0","1000","user","AdminAsset","index","","资源管理","file","资源管理列表");
INSERT INTO cmf_admin_menu VALUES("122","121","2","0","1000","user","AdminAsset","delete","","删除文件","","删除文件");
INSERT INTO cmf_admin_menu VALUES("123","110","0","1","10000","user","AdminIndex","default1","","用户组","","用户组");
INSERT INTO cmf_admin_menu VALUES("124","123","1","1","10000","user","AdminIndex","index","","本站用户","","本站用户");
INSERT INTO cmf_admin_menu VALUES("125","124","2","0","10000","user","AdminIndex","ban","","本站用户拉黑","","本站用户拉黑");
INSERT INTO cmf_admin_menu VALUES("126","124","2","0","10000","user","AdminIndex","cancelBan","","本站用户启用","","本站用户启用");
INSERT INTO cmf_admin_menu VALUES("127","123","1","1","10000","user","AdminOauth","index","","第三方用户","","第三方用户");
INSERT INTO cmf_admin_menu VALUES("128","127","2","0","10000","user","AdminOauth","delete","","删除第三方用户绑定","","删除第三方用户绑定");
INSERT INTO cmf_admin_menu VALUES("130","129","1","0","1000","user","AdminUserAction","edit","","编辑用户操作","","编辑用户操作");
INSERT INTO cmf_admin_menu VALUES("131","129","2","0","1000","user","AdminUserAction","editPost","","编辑用户操作提交","","编辑用户操作提交");
INSERT INTO cmf_admin_menu VALUES("132","129","1","0","1000","user","AdminUserAction","sync","","同步用户操作","","同步用户操作");
INSERT INTO cmf_admin_menu VALUES("162","58","2","0","1000","admin","RecycleBin","clear","","清空回收站","","一键清空回收站");
INSERT INTO cmf_admin_menu VALUES("163","1","1","1","1000","plugin/Swagger","AdminIndex","index","","Swagger","","Swagger");
INSERT INTO cmf_admin_menu VALUES("164","6","1","1","10","plugin/Configs","AdminIndex","index","","系统参数设置","","系统参数设置");
INSERT INTO cmf_admin_menu VALUES("167","0","1","1","1000","admin","member","default","","用户管理","user-o","");
INSERT INTO cmf_admin_menu VALUES("168","167","1","1","1000","admin","member","index","","用户管理","","");
INSERT INTO cmf_admin_menu VALUES("169","1","1","1","1000","/plugin/form","AdminIndex","setting","","生成CURD","","");
INSERT INTO cmf_admin_menu VALUES("179","0","1","1","8000","admin","dingdan","index","","订单管理","reorder","");
INSERT INTO cmf_admin_menu VALUES("180","179","1","1","1000","admin","shop_order","index","","订单管理","","");
INSERT INTO cmf_admin_menu VALUES("183","182","1","0","10000","admin","Shop","edit","","编辑","","");
INSERT INTO cmf_admin_menu VALUES("184","182","1","0","10000","admin","Shop","add","","添加","","");
INSERT INTO cmf_admin_menu VALUES("185","182","1","0","10000","admin","Shop","find","","查看","","");
INSERT INTO cmf_admin_menu VALUES("186","182","1","0","10000","admin","Shop","delete","","删除","","");
INSERT INTO cmf_admin_menu VALUES("191","190","1","0","10000","admin","FormTest","edit","","编辑","","");
INSERT INTO cmf_admin_menu VALUES("192","190","1","0","10000","admin","FormTest","add","","添加","","");
INSERT INTO cmf_admin_menu VALUES("193","190","1","0","10000","admin","FormTest","find","","查看","","");
INSERT INTO cmf_admin_menu VALUES("194","190","1","0","10000","admin","FormTest","delete","","删除","","");
INSERT INTO cmf_admin_menu VALUES("195","190","1","0","10000","admin","FormTest","recommend_post","","推荐","","");
INSERT INTO cmf_admin_menu VALUES("196","190","1","0","10000","admin","FormTest","list_order_post","","排序","","");
INSERT INTO cmf_admin_menu VALUES("198","6","1","1","10000","plugin/weipay","admin_index","index","","小程序设置","","");
INSERT INTO cmf_admin_menu VALUES("199","0","2","0","10000","admin","moren","index","","子权限","","");
INSERT INTO cmf_admin_menu VALUES("200","0","1","1","3000","admin","shangpin","index","","商品管理","quora","");
INSERT INTO cmf_admin_menu VALUES("201","200","1","1","10000","admin","ShopGoods","index","","商品管理","","");
INSERT INTO cmf_admin_menu VALUES("202","201","1","0","10000","admin","ShopGoods","edit","","编辑","","");
INSERT INTO cmf_admin_menu VALUES("203","201","1","0","10000","admin","ShopGoods","add","","添加","","");
INSERT INTO cmf_admin_menu VALUES("204","201","1","0","10000","admin","ShopGoods","delete","","删除","","");
INSERT INTO cmf_admin_menu VALUES("205","201","1","0","10000","admin","ShopGoods","list_order_post","","排序","","");
INSERT INTO cmf_admin_menu VALUES("210","200","1","1","10000","admin","ShopGoodsClass","index","","分类管理","","");
INSERT INTO cmf_admin_menu VALUES("211","210","1","0","10000","admin","ShopGoodsClass","edit","","编辑","","");
INSERT INTO cmf_admin_menu VALUES("212","210","1","0","10000","admin","ShopGoodsClass","add","","添加","","");
INSERT INTO cmf_admin_menu VALUES("213","210","1","0","10000","admin","ShopGoodsClass","delete","","删除","","");
INSERT INTO cmf_admin_menu VALUES("214","210","1","0","10000","admin","ShopGoodsClass","list_order_post","","排序","","");
INSERT INTO cmf_admin_menu VALUES("215","0","1","1","4000","admin","jishi","index","","技师管理","child","");
INSERT INTO cmf_admin_menu VALUES("216","215","1","1","10000","admin","Technician","index","","技师管理","","");
INSERT INTO cmf_admin_menu VALUES("217","216","1","0","10000","admin","Technician","find","","查看","","");
INSERT INTO cmf_admin_menu VALUES("218","215","1","0","10000","admin","RoadPrice","index","","路费配置","","");
INSERT INTO cmf_admin_menu VALUES("219","218","1","0","10000","admin","RoadPrice","edit","","编辑","","");
INSERT INTO cmf_admin_menu VALUES("220","218","1","0","10000","admin","RoadPrice","add","","添加","","");
INSERT INTO cmf_admin_menu VALUES("221","218","1","0","10000","admin","RoadPrice","delete","","删除","","");
INSERT INTO cmf_admin_menu VALUES("222","218","1","0","10000","admin","RoadPrice","list_order_post","","排序","","");
INSERT INTO cmf_admin_menu VALUES("223","0","1","1","8100","admin","youhuiquan","index","","优惠券","ticket","");
INSERT INTO cmf_admin_menu VALUES("224","223","1","1","10000","admin","ShopCoupon","index","","优惠券","","");
INSERT INTO cmf_admin_menu VALUES("225","224","1","0","10000","admin","ShopCoupon","edit","","编辑","","");
INSERT INTO cmf_admin_menu VALUES("226","224","1","0","10000","admin","ShopCoupon","add","","添加","","");
INSERT INTO cmf_admin_menu VALUES("227","224","1","0","10000","admin","ShopCoupon","delete","","删除","","");
INSERT INTO cmf_admin_menu VALUES("228","224","1","0","10000","admin","ShopCoupon","list_order_post","","排序","","");
INSERT INTO cmf_admin_menu VALUES("229","167","1","1","10000","admin","MemberRecharge","index","","充值管理","","");
INSERT INTO cmf_admin_menu VALUES("230","229","1","0","10000","admin","MemberRecharge","edit","","编辑","","");
INSERT INTO cmf_admin_menu VALUES("231","229","1","0","10000","admin","MemberRecharge","add","","添加","","");
INSERT INTO cmf_admin_menu VALUES("232","229","1","0","10000","admin","MemberRecharge","delete","","删除","","");
INSERT INTO cmf_admin_menu VALUES("233","229","1","0","10000","admin","MemberRecharge","list_order_post","","排序","","");
INSERT INTO cmf_admin_menu VALUES("234","0","1","1","8200","admin","Problem","index","","常见问题","question-circle-o","");
INSERT INTO cmf_admin_menu VALUES("235","234","1","0","10000","admin","Problem","edit","","编辑","","");
INSERT INTO cmf_admin_menu VALUES("236","234","1","0","10000","admin","Problem","add","","添加","","");
INSERT INTO cmf_admin_menu VALUES("237","234","1","0","10000","admin","Problem","delete","","删除","","");
INSERT INTO cmf_admin_menu VALUES("238","234","1","0","10000","admin","Problem","list_order_post","","排序","","");
INSERT INTO cmf_admin_menu VALUES("239","0","1","1","8300","admin","Leave","index","","意见反馈","envelope-open","");
INSERT INTO cmf_admin_menu VALUES("240","239","1","0","10000","admin","Leave","find","","查看","","");
INSERT INTO cmf_admin_menu VALUES("241","0","1","1","8400","admin","withdrawal","index","","提现管理","check","");
INSERT INTO cmf_admin_menu VALUES("243","6","1","1","10000","admin","storage","index","","文件存储","","");
INSERT INTO cmf_admin_menu VALUES("244","0","1","1","9000","admin","ShopOrderComplaint","index","","订单投诉","exclamation-triangle","");
INSERT INTO cmf_admin_menu VALUES("245","244","1","0","10000","admin","ShopOrderComplaint","find","","查看","","");
INSERT INTO cmf_admin_menu VALUES("246","0","1","1","9100","admin","shop_order_address","alarm_list","","报警管理","bell","");
INSERT INTO cmf_admin_menu VALUES("247","78","1","1","10000","admin","Slide","index","","分类管理","","");
INSERT INTO cmf_admin_menu VALUES("248","78","1","1","10000","admin","Link","index","","链接管理","","");



CREATE TABLE `cmf_asset` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `file_size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小,单位B',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态;1:可用,0:不可用',
  `download_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `file_key` varchar(64) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '文件惟一码',
  `filename` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '文件名',
  `file_path` varchar(100) NOT NULL DEFAULT '' COMMENT '文件路径,相对于upload目录,可以为url',
  `file_md5` varchar(32) NOT NULL DEFAULT '' COMMENT '文件md5值',
  `file_sha1` varchar(40) NOT NULL DEFAULT '',
  `suffix` varchar(10) NOT NULL DEFAULT '' COMMENT '文件后缀名,不包括点',
  `more` text COMMENT '其它详细信息,JSON格式',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='资源表';

DROP TABLE cmf_auth_access;

CREATE TABLE `cmf_auth_access` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL COMMENT '角色',
  `rule_name` varchar(100) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识,全小写',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '权限规则分类,请加应用前缀,如admin_',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `role_id` (`role_id`) USING BTREE,
  KEY `rule_name` (`rule_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8 COMMENT='权限授权表';

INSERT INTO cmf_auth_access VALUES("135","2","admin/member/default","admin_url");
INSERT INTO cmf_auth_access VALUES("136","2","admin/member/index","admin_url");
INSERT INTO cmf_auth_access VALUES("137","2","admin/plugin/default","admin_url");
INSERT INTO cmf_auth_access VALUES("138","2","admin/hook/index","admin_url");
INSERT INTO cmf_auth_access VALUES("139","2","admin/hook/plugins","admin_url");
INSERT INTO cmf_auth_access VALUES("140","2","admin/hook/pluginlistorder","admin_url");
INSERT INTO cmf_auth_access VALUES("141","2","admin/hook/sync","admin_url");
INSERT INTO cmf_auth_access VALUES("142","2","admin/plugin/index","admin_url");
INSERT INTO cmf_auth_access VALUES("143","2","admin/plugin/toggle","admin_url");
INSERT INTO cmf_auth_access VALUES("144","2","admin/plugin/setting","admin_url");
INSERT INTO cmf_auth_access VALUES("145","2","admin/plugin/settingpost","admin_url");
INSERT INTO cmf_auth_access VALUES("146","2","admin/plugin/install","admin_url");
INSERT INTO cmf_auth_access VALUES("147","2","admin/plugin/update","admin_url");
INSERT INTO cmf_auth_access VALUES("148","2","admin/plugin/uninstall","admin_url");
INSERT INTO cmf_auth_access VALUES("149","2","plugin/swagger/adminindex/index","admin_url");
INSERT INTO cmf_auth_access VALUES("150","2","/plugin/form/adminindex/setting","admin_url");



DROP TABLE cmf_auth_rule;

CREATE TABLE `cmf_auth_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `app` varchar(40) NOT NULL DEFAULT '' COMMENT '规则所属app',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '权限规则分类，请加应用前缀,如admin_',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识,全小写',
  `param` varchar(100) NOT NULL DEFAULT '' COMMENT '额外url参数',
  `title` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '规则描述',
  `condition` varchar(200) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name` (`name`) USING BTREE,
  KEY `module` (`app`,`status`,`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=234 DEFAULT CHARSET=utf8mb4 COMMENT='权限规则表';

INSERT INTO cmf_auth_rule VALUES("1","1","admin","admin_url","admin/Hook/index","","钩子管理","");
INSERT INTO cmf_auth_rule VALUES("2","1","admin","admin_url","admin/Hook/plugins","","钩子插件管理","");
INSERT INTO cmf_auth_rule VALUES("3","1","admin","admin_url","admin/Hook/pluginListOrder","","钩子插件排序","");
INSERT INTO cmf_auth_rule VALUES("4","1","admin","admin_url","admin/Hook/sync","","同步钩子","");
INSERT INTO cmf_auth_rule VALUES("5","1","admin","admin_url","admin/Link/index","","友情链接","");
INSERT INTO cmf_auth_rule VALUES("6","1","admin","admin_url","admin/Link/add","","添加友情链接","");
INSERT INTO cmf_auth_rule VALUES("7","1","admin","admin_url","admin/Link/addPost","","添加友情链接提交保存","");
INSERT INTO cmf_auth_rule VALUES("8","1","admin","admin_url","admin/Link/edit","","编辑友情链接","");
INSERT INTO cmf_auth_rule VALUES("9","1","admin","admin_url","admin/Link/editPost","","编辑友情链接提交保存","");
INSERT INTO cmf_auth_rule VALUES("10","1","admin","admin_url","admin/Link/delete","","删除友情链接","");
INSERT INTO cmf_auth_rule VALUES("11","1","admin","admin_url","admin/Link/listOrder","","友情链接排序","");
INSERT INTO cmf_auth_rule VALUES("12","1","admin","admin_url","admin/Link/toggle","","友情链接显示隐藏","");
INSERT INTO cmf_auth_rule VALUES("13","1","admin","admin_url","admin/Mailer/index","","邮箱配置","");
INSERT INTO cmf_auth_rule VALUES("14","1","admin","admin_url","admin/Mailer/indexPost","","邮箱配置提交保存","");
INSERT INTO cmf_auth_rule VALUES("15","1","admin","admin_url","admin/Mailer/template","","邮件模板","");
INSERT INTO cmf_auth_rule VALUES("16","1","admin","admin_url","admin/Mailer/templatePost","","邮件模板提交","");
INSERT INTO cmf_auth_rule VALUES("17","1","admin","admin_url","admin/Mailer/test","","邮件发送测试","");
INSERT INTO cmf_auth_rule VALUES("18","1","admin","admin_url","admin/Menu/index","","后台菜单","");
INSERT INTO cmf_auth_rule VALUES("19","1","admin","admin_url","admin/Menu/lists","","所有菜单","");
INSERT INTO cmf_auth_rule VALUES("20","1","admin","admin_url","admin/Menu/add","","后台菜单添加","");
INSERT INTO cmf_auth_rule VALUES("21","1","admin","admin_url","admin/Menu/addPost","","后台菜单添加提交保存","");
INSERT INTO cmf_auth_rule VALUES("22","1","admin","admin_url","admin/Menu/edit","","后台菜单编辑","");
INSERT INTO cmf_auth_rule VALUES("23","1","admin","admin_url","admin/Menu/editPost","","后台菜单编辑提交保存","");
INSERT INTO cmf_auth_rule VALUES("24","1","admin","admin_url","admin/Menu/delete","","后台菜单删除","");
INSERT INTO cmf_auth_rule VALUES("25","1","admin","admin_url","admin/Menu/listOrder","","后台菜单排序","");
INSERT INTO cmf_auth_rule VALUES("26","1","admin","admin_url","admin/Menu/getActions","","导入新后台菜单","");
INSERT INTO cmf_auth_rule VALUES("27","1","admin","admin_url","admin/Nav/index","","导航管理","");
INSERT INTO cmf_auth_rule VALUES("28","1","admin","admin_url","admin/Nav/add","","添加导航","");
INSERT INTO cmf_auth_rule VALUES("29","1","admin","admin_url","admin/Nav/addPost","","添加导航提交保存","");
INSERT INTO cmf_auth_rule VALUES("30","1","admin","admin_url","admin/Nav/edit","","编辑导航","");
INSERT INTO cmf_auth_rule VALUES("31","1","admin","admin_url","admin/Nav/editPost","","编辑导航提交保存","");
INSERT INTO cmf_auth_rule VALUES("32","1","admin","admin_url","admin/Nav/delete","","删除导航","");
INSERT INTO cmf_auth_rule VALUES("33","1","admin","admin_url","admin/NavMenu/index","","导航菜单","");
INSERT INTO cmf_auth_rule VALUES("34","1","admin","admin_url","admin/NavMenu/add","","添加导航菜单","");
INSERT INTO cmf_auth_rule VALUES("35","1","admin","admin_url","admin/NavMenu/addPost","","添加导航菜单提交保存","");
INSERT INTO cmf_auth_rule VALUES("36","1","admin","admin_url","admin/NavMenu/edit","","编辑导航菜单","");
INSERT INTO cmf_auth_rule VALUES("37","1","admin","admin_url","admin/NavMenu/editPost","","编辑导航菜单提交保存","");
INSERT INTO cmf_auth_rule VALUES("38","1","admin","admin_url","admin/NavMenu/delete","","删除导航菜单","");
INSERT INTO cmf_auth_rule VALUES("39","1","admin","admin_url","admin/NavMenu/listOrder","","导航菜单排序","");
INSERT INTO cmf_auth_rule VALUES("40","1","admin","admin_url","admin/Plugin/default","","插件中心","");
INSERT INTO cmf_auth_rule VALUES("41","1","admin","admin_url","admin/Plugin/index","","插件列表","");
INSERT INTO cmf_auth_rule VALUES("42","1","admin","admin_url","admin/Plugin/toggle","","插件启用禁用","");
INSERT INTO cmf_auth_rule VALUES("43","1","admin","admin_url","admin/Plugin/setting","","插件设置","");
INSERT INTO cmf_auth_rule VALUES("44","1","admin","admin_url","admin/Plugin/settingPost","","插件设置提交","");
INSERT INTO cmf_auth_rule VALUES("45","1","admin","admin_url","admin/Plugin/install","","插件安装","");
INSERT INTO cmf_auth_rule VALUES("46","1","admin","admin_url","admin/Plugin/update","","插件更新","");
INSERT INTO cmf_auth_rule VALUES("47","1","admin","admin_url","admin/Plugin/uninstall","","卸载插件","");
INSERT INTO cmf_auth_rule VALUES("48","1","admin","admin_url","admin/Rbac/index","","角色管理","");
INSERT INTO cmf_auth_rule VALUES("49","1","admin","admin_url","admin/Rbac/roleAdd","","添加角色","");
INSERT INTO cmf_auth_rule VALUES("50","1","admin","admin_url","admin/Rbac/roleAddPost","","添加角色提交","");
INSERT INTO cmf_auth_rule VALUES("51","1","admin","admin_url","admin/Rbac/roleEdit","","编辑角色","");
INSERT INTO cmf_auth_rule VALUES("52","1","admin","admin_url","admin/Rbac/roleEditPost","","编辑角色提交","");
INSERT INTO cmf_auth_rule VALUES("53","1","admin","admin_url","admin/Rbac/roleDelete","","删除角色","");
INSERT INTO cmf_auth_rule VALUES("54","1","admin","admin_url","admin/Rbac/authorize","","设置角色权限","");
INSERT INTO cmf_auth_rule VALUES("55","1","admin","admin_url","admin/Rbac/authorizePost","","角色授权提交","");
INSERT INTO cmf_auth_rule VALUES("56","1","admin","admin_url","admin/RecycleBin/index","","回收站","");
INSERT INTO cmf_auth_rule VALUES("57","1","admin","admin_url","admin/RecycleBin/restore","","回收站还原","");
INSERT INTO cmf_auth_rule VALUES("58","1","admin","admin_url","admin/RecycleBin/delete","","回收站彻底删除","");
INSERT INTO cmf_auth_rule VALUES("59","1","admin","admin_url","admin/Route/index","","URL美化","");
INSERT INTO cmf_auth_rule VALUES("60","1","admin","admin_url","admin/Route/add","","添加路由规则","");
INSERT INTO cmf_auth_rule VALUES("61","1","admin","admin_url","admin/Route/addPost","","添加路由规则提交","");
INSERT INTO cmf_auth_rule VALUES("62","1","admin","admin_url","admin/Route/edit","","路由规则编辑","");
INSERT INTO cmf_auth_rule VALUES("63","1","admin","admin_url","admin/Route/editPost","","路由规则编辑提交","");
INSERT INTO cmf_auth_rule VALUES("64","1","admin","admin_url","admin/Route/delete","","路由规则删除","");
INSERT INTO cmf_auth_rule VALUES("65","1","admin","admin_url","admin/Route/ban","","路由规则禁用","");
INSERT INTO cmf_auth_rule VALUES("66","1","admin","admin_url","admin/Route/open","","路由规则启用","");
INSERT INTO cmf_auth_rule VALUES("67","1","admin","admin_url","admin/Route/listOrder","","路由规则排序","");
INSERT INTO cmf_auth_rule VALUES("68","1","admin","admin_url","admin/Route/select","","选择URL","");
INSERT INTO cmf_auth_rule VALUES("69","1","admin","admin_url","admin/Setting/default","","设置","");
INSERT INTO cmf_auth_rule VALUES("70","1","admin","admin_url","admin/Setting/site","","网站信息","");
INSERT INTO cmf_auth_rule VALUES("71","1","admin","admin_url","admin/Setting/sitePost","","网站信息设置提交","");
INSERT INTO cmf_auth_rule VALUES("72","1","admin","admin_url","admin/Setting/password","","密码修改","");
INSERT INTO cmf_auth_rule VALUES("73","1","admin","admin_url","admin/Setting/passwordPost","","密码修改提交","");
INSERT INTO cmf_auth_rule VALUES("74","1","admin","admin_url","admin/Setting/upload","","上传设置","");
INSERT INTO cmf_auth_rule VALUES("75","1","admin","admin_url","admin/Setting/uploadPost","","上传设置提交","");
INSERT INTO cmf_auth_rule VALUES("76","1","admin","admin_url","admin/Setting/clearCache","","清除缓存","");
INSERT INTO cmf_auth_rule VALUES("77","1","admin","admin_url","admin/Slide/de","","幻灯片管理","");
INSERT INTO cmf_auth_rule VALUES("78","1","admin","admin_url","admin/Slide/add","","添加幻灯片","");
INSERT INTO cmf_auth_rule VALUES("79","1","admin","admin_url","admin/Slide/addPost","","添加幻灯片提交","");
INSERT INTO cmf_auth_rule VALUES("80","1","admin","admin_url","admin/Slide/edit","","编辑幻灯片","");
INSERT INTO cmf_auth_rule VALUES("81","1","admin","admin_url","admin/Slide/editPost","","编辑幻灯片提交","");
INSERT INTO cmf_auth_rule VALUES("82","1","admin","admin_url","admin/Slide/delete","","删除幻灯片","");
INSERT INTO cmf_auth_rule VALUES("83","1","admin","admin_url","admin/SlideItem/index","","幻灯片页面列表","");
INSERT INTO cmf_auth_rule VALUES("84","1","admin","admin_url","admin/SlideItem/add","","幻灯片页面添加","");
INSERT INTO cmf_auth_rule VALUES("85","1","admin","admin_url","admin/SlideItem/addPost","","幻灯片页面添加提交","");
INSERT INTO cmf_auth_rule VALUES("86","1","admin","admin_url","admin/SlideItem/edit","","幻灯片页面编辑","");
INSERT INTO cmf_auth_rule VALUES("87","1","admin","admin_url","admin/SlideItem/editPost","","幻灯片页面编辑提交","");
INSERT INTO cmf_auth_rule VALUES("88","1","admin","admin_url","admin/SlideItem/delete","","幻灯片页面删除","");
INSERT INTO cmf_auth_rule VALUES("89","1","admin","admin_url","admin/SlideItem/ban","","幻灯片页面隐藏","");
INSERT INTO cmf_auth_rule VALUES("90","1","admin","admin_url","admin/SlideItem/cancelBan","","幻灯片页面显示","");
INSERT INTO cmf_auth_rule VALUES("91","1","admin","admin_url","admin/SlideItem/listOrder","","幻灯片页面排序","");
INSERT INTO cmf_auth_rule VALUES("92","1","admin","admin_url","admin/Storage/index","","文件存储","");
INSERT INTO cmf_auth_rule VALUES("93","1","admin","admin_url","admin/Storage/settingPost","","文件存储设置提交","");
INSERT INTO cmf_auth_rule VALUES("94","1","admin","admin_url","admin/Theme/index","","模板管理","");
INSERT INTO cmf_auth_rule VALUES("95","1","admin","admin_url","admin/Theme/install","","安装模板","");
INSERT INTO cmf_auth_rule VALUES("96","1","admin","admin_url","admin/Theme/uninstall","","卸载模板","");
INSERT INTO cmf_auth_rule VALUES("97","1","admin","admin_url","admin/Theme/installTheme","","模板安装","");
INSERT INTO cmf_auth_rule VALUES("98","1","admin","admin_url","admin/Theme/update","","模板更新","");
INSERT INTO cmf_auth_rule VALUES("99","1","admin","admin_url","admin/Theme/active","","启用模板","");
INSERT INTO cmf_auth_rule VALUES("100","1","admin","admin_url","admin/Theme/files","","模板文件列表","");
INSERT INTO cmf_auth_rule VALUES("101","1","admin","admin_url","admin/Theme/fileSetting","","模板文件设置","");
INSERT INTO cmf_auth_rule VALUES("102","1","admin","admin_url","admin/Theme/fileArrayData","","模板文件数组数据列表","");
INSERT INTO cmf_auth_rule VALUES("103","1","admin","admin_url","admin/Theme/fileArrayDataEdit","","模板文件数组数据添加编辑","");
INSERT INTO cmf_auth_rule VALUES("104","1","admin","admin_url","admin/Theme/fileArrayDataEditPost","","模板文件数组数据添加编辑提交保存","");
INSERT INTO cmf_auth_rule VALUES("105","1","admin","admin_url","admin/Theme/fileArrayDataDelete","","模板文件数组数据删除","");
INSERT INTO cmf_auth_rule VALUES("106","1","admin","admin_url","admin/Theme/settingPost","","模板文件编辑提交保存","");
INSERT INTO cmf_auth_rule VALUES("107","1","admin","admin_url","admin/Theme/dataSource","","模板文件设置数据源","");
INSERT INTO cmf_auth_rule VALUES("108","1","admin","admin_url","admin/Theme/design","","模板设计","");
INSERT INTO cmf_auth_rule VALUES("109","1","admin","admin_url","admin/User/default","","管理组","");
INSERT INTO cmf_auth_rule VALUES("110","1","admin","admin_url","admin/User/index","","管理员","");
INSERT INTO cmf_auth_rule VALUES("111","1","admin","admin_url","admin/User/add","","管理员添加","");
INSERT INTO cmf_auth_rule VALUES("112","1","admin","admin_url","admin/User/addPost","","管理员添加提交","");
INSERT INTO cmf_auth_rule VALUES("113","1","admin","admin_url","admin/User/edit","","管理员编辑","");
INSERT INTO cmf_auth_rule VALUES("114","1","admin","admin_url","admin/User/editPost","","管理员编辑提交","");
INSERT INTO cmf_auth_rule VALUES("115","1","admin","admin_url","admin/User/userInfo","","个人信息","");
INSERT INTO cmf_auth_rule VALUES("116","1","admin","admin_url","admin/User/userInfoPost","","管理员个人信息修改提交","");
INSERT INTO cmf_auth_rule VALUES("117","1","admin","admin_url","admin/User/delete","","管理员删除","");
INSERT INTO cmf_auth_rule VALUES("118","1","admin","admin_url","admin/User/ban","","停用管理员","");
INSERT INTO cmf_auth_rule VALUES("119","1","admin","admin_url","admin/User/cancelBan","","启用管理员","");
INSERT INTO cmf_auth_rule VALUES("120","1","user","admin_url","user/AdminAsset/index","","资源管理","");
INSERT INTO cmf_auth_rule VALUES("121","1","user","admin_url","user/AdminAsset/delete","","删除文件","");
INSERT INTO cmf_auth_rule VALUES("122","1","user","admin_url","user/AdminIndex/default","","管理员","");
INSERT INTO cmf_auth_rule VALUES("123","1","user","admin_url","user/AdminIndex/default1","","用户组","");
INSERT INTO cmf_auth_rule VALUES("124","1","user","admin_url","user/AdminIndex/index","","本站用户","");
INSERT INTO cmf_auth_rule VALUES("125","1","user","admin_url","user/AdminIndex/ban","","本站用户拉黑","");
INSERT INTO cmf_auth_rule VALUES("126","1","user","admin_url","user/AdminIndex/cancelBan","","本站用户启用","");
INSERT INTO cmf_auth_rule VALUES("127","1","user","admin_url","user/AdminOauth/index","","第三方用户","");
INSERT INTO cmf_auth_rule VALUES("128","1","user","admin_url","user/AdminOauth/delete","","删除第三方用户绑定","");
INSERT INTO cmf_auth_rule VALUES("129","1","user","admin_url","user/AdminUserAction/index","","用户操作管理","");
INSERT INTO cmf_auth_rule VALUES("130","1","user","admin_url","user/AdminUserAction/edit","","编辑用户操作","");
INSERT INTO cmf_auth_rule VALUES("131","1","user","admin_url","user/AdminUserAction/editPost","","编辑用户操作提交","");
INSERT INTO cmf_auth_rule VALUES("132","1","user","admin_url","user/AdminUserAction/sync","","同步用户操作","");
INSERT INTO cmf_auth_rule VALUES("133","1","admin","admin_url","admin/AppInfo/index","","应用设置","");
INSERT INTO cmf_auth_rule VALUES("162","1","admin","admin_url","admin/RecycleBin/clear","","清空回收站","");
INSERT INTO cmf_auth_rule VALUES("163","1","plugin/Swagger","plugin_url","plugin/Swagger/AdminIndex/index","","Swagger","");
INSERT INTO cmf_auth_rule VALUES("164","1","plugin/Configs","plugin_url","plugin/Configs/AdminIndex/index","","系统参数设置","");
INSERT INTO cmf_auth_rule VALUES("166","1","plugin/AdminJournal","admin_url","plugin/AdminJournal/AdminIndex/index","","操作日志","");
INSERT INTO cmf_auth_rule VALUES("167","1","admin","admin_url","admin/member/default","","用户管理","");
INSERT INTO cmf_auth_rule VALUES("168","1","admin","admin_url","admin/member/index","","用户管理","");
INSERT INTO cmf_auth_rule VALUES("169","1","/plugin/form","admin_url","/plugin/form/AdminIndex/setting","","生成CURD","");
INSERT INTO cmf_auth_rule VALUES("177","1","admin","admin_url","admin/dingdan/index","","订单管理","");
INSERT INTO cmf_auth_rule VALUES("178","1","admin","admin_url","admin/shop_order/index","","订单管理","");
INSERT INTO cmf_auth_rule VALUES("179","1","admin","admin_url","admin/Shop/index","","店铺管理","");
INSERT INTO cmf_auth_rule VALUES("180","1","admin","admin_url","admin/Shop/edit","","店铺管理-编辑","");
INSERT INTO cmf_auth_rule VALUES("181","1","admin","admin_url","admin/Shop/add","","店铺管理-添加","");
INSERT INTO cmf_auth_rule VALUES("182","1","admin","admin_url","admin/Shop/find","","店铺管理-查看","");
INSERT INTO cmf_auth_rule VALUES("183","1","admin","admin_url","admin/Shop/delete","","店铺管理-删除","");
INSERT INTO cmf_auth_rule VALUES("184","1","admin","admin_url","admin/FormTest/index","","测试生成crud","");
INSERT INTO cmf_auth_rule VALUES("185","1","admin","admin_url","admin/FormTest/edit","","测试生成crud-编辑","");
INSERT INTO cmf_auth_rule VALUES("186","1","admin","admin_url","admin/FormTest/add","","测试生成crud-添加","");
INSERT INTO cmf_auth_rule VALUES("187","1","admin","admin_url","admin/FormTest/find","","测试生成crud-查看","");
INSERT INTO cmf_auth_rule VALUES("188","1","admin","admin_url","admin/FormTest/delete","","测试生成crud-删除","");
INSERT INTO cmf_auth_rule VALUES("189","1","admin","admin_url","admin/FormTest/recommend_post","","测试生成crud-推荐","");
INSERT INTO cmf_auth_rule VALUES("190","1","admin","admin_url","admin/FormTest/list_order_post","","测试生成crud-排序","");
INSERT INTO cmf_auth_rule VALUES("191","1","admin","admin_url","admin/test/index","","测试","");
INSERT INTO cmf_auth_rule VALUES("192","1","plugin/weipay","admin_url","plugin/weipay/admin_index/index","","小程序设置","");
INSERT INTO cmf_auth_rule VALUES("193","1","admin","admin_url","admin/moren/index","","子权限","");
INSERT INTO cmf_auth_rule VALUES("194","1","admin","admin_url","admin/shangpin/index","","商品管理","");
INSERT INTO cmf_auth_rule VALUES("195","1","admin","admin_url","admin/ShopGoods/index","","商品管理","");
INSERT INTO cmf_auth_rule VALUES("196","1","admin","admin_url","admin/ShopGoods/edit","","商品管理-编辑","");
INSERT INTO cmf_auth_rule VALUES("197","1","admin","admin_url","admin/ShopGoods/add","","商品管理-添加","");
INSERT INTO cmf_auth_rule VALUES("198","1","admin","admin_url","admin/ShopGoods/delete","","商品管理-删除","");
INSERT INTO cmf_auth_rule VALUES("199","1","admin","admin_url","admin/ShopGoods/list_order_post","","商品管理-排序","");
INSERT INTO cmf_auth_rule VALUES("200","1","admin","admin_url","admin/ShopGoodsClass/index","","分类管理","");
INSERT INTO cmf_auth_rule VALUES("201","1","admin","admin_url","admin/ShopGoodsClass/edit","","分类管理-编辑","");
INSERT INTO cmf_auth_rule VALUES("202","1","admin","admin_url","admin/ShopGoodsClass/add","","分类管理-添加","");
INSERT INTO cmf_auth_rule VALUES("203","1","admin","admin_url","admin/ShopGoodsClass/delete","","分类管理-删除","");
INSERT INTO cmf_auth_rule VALUES("204","1","admin","admin_url","admin/ShopGoodsClass/list_order_post","","分类管理-排序","");
INSERT INTO cmf_auth_rule VALUES("205","1","admin","admin_url","admin/jishi/index","","技师管理","");
INSERT INTO cmf_auth_rule VALUES("206","1","admin","admin_url","admin/Technician/index","","技师管理","");
INSERT INTO cmf_auth_rule VALUES("207","1","admin","admin_url","admin/Technician/find","","技师管理-查看","");
INSERT INTO cmf_auth_rule VALUES("208","1","admin","admin_url","admin/RoadPrice/index","","路费配置","");
INSERT INTO cmf_auth_rule VALUES("209","1","admin","admin_url","admin/RoadPrice/edit","","路费配置-编辑","");
INSERT INTO cmf_auth_rule VALUES("210","1","admin","admin_url","admin/RoadPrice/add","","路费配置-添加","");
INSERT INTO cmf_auth_rule VALUES("211","1","admin","admin_url","admin/RoadPrice/delete","","路费配置-删除","");
INSERT INTO cmf_auth_rule VALUES("212","1","admin","admin_url","admin/RoadPrice/list_order_post","","路费配置-排序","");
INSERT INTO cmf_auth_rule VALUES("213","1","admin","admin_url","admin/youhuiquan/index","","优惠券","");
INSERT INTO cmf_auth_rule VALUES("214","1","admin","admin_url","admin/ShopCoupon/index","","优惠券","");
INSERT INTO cmf_auth_rule VALUES("215","1","admin","admin_url","admin/ShopCoupon/edit","","优惠券-编辑","");
INSERT INTO cmf_auth_rule VALUES("216","1","admin","admin_url","admin/ShopCoupon/add","","优惠券-添加","");
INSERT INTO cmf_auth_rule VALUES("217","1","admin","admin_url","admin/ShopCoupon/delete","","优惠券-删除","");
INSERT INTO cmf_auth_rule VALUES("218","1","admin","admin_url","admin/ShopCoupon/list_order_post","","优惠券-排序","");
INSERT INTO cmf_auth_rule VALUES("219","1","admin","admin_url","admin/MemberRecharge/index","","充值管理","");
INSERT INTO cmf_auth_rule VALUES("220","1","admin","admin_url","admin/MemberRecharge/edit","","充值管理-编辑","");
INSERT INTO cmf_auth_rule VALUES("221","1","admin","admin_url","admin/MemberRecharge/add","","充值管理-添加","");
INSERT INTO cmf_auth_rule VALUES("222","1","admin","admin_url","admin/MemberRecharge/delete","","充值管理-删除","");
INSERT INTO cmf_auth_rule VALUES("223","1","admin","admin_url","admin/MemberRecharge/list_order_post","","充值管理-排序","");
INSERT INTO cmf_auth_rule VALUES("224","1","admin","admin_url","admin/Problem/index","","常见问题","");
INSERT INTO cmf_auth_rule VALUES("225","1","admin","admin_url","admin/Problem/edit","","常见问题-编辑","");
INSERT INTO cmf_auth_rule VALUES("226","1","admin","admin_url","admin/Problem/add","","常见问题-添加","");
INSERT INTO cmf_auth_rule VALUES("227","1","admin","admin_url","admin/Problem/delete","","常见问题-删除","");
INSERT INTO cmf_auth_rule VALUES("228","1","admin","admin_url","admin/Problem/list_order_post","","常见问题-排序","");
INSERT INTO cmf_auth_rule VALUES("229","1","admin","admin_url","admin/Leave/index","","意见反馈","");
INSERT INTO cmf_auth_rule VALUES("230","1","admin","admin_url","admin/Leave/find","","意见反馈-查看","");
INSERT INTO cmf_auth_rule VALUES("231","1","admin","admin_url","admin/withdrawal/index","","提现管理","");
INSERT INTO cmf_auth_rule VALUES("232","1","admin","admin_url","admin/guanlizu/index","","管理组","");
INSERT INTO cmf_auth_rule VALUES("233","1","admin","admin_url","admin/Slide/index","","分类管理","");



CREATE TABLE `cmf_base_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) DEFAULT '1' COMMENT '1后台  2前端',
  `log` longtext COMMENT '操作地址参数',
  `admin_id` int(11) DEFAULT NULL COMMENT '登录人',
  `admin_name` varchar(200) DEFAULT NULL COMMENT '昵称',
  `openid` varchar(255) DEFAULT NULL COMMENT '登录标识',
  `ip` varchar(200) DEFAULT NULL COMMENT 'IP地址',
  `menu_name` varchar(250) DEFAULT NULL COMMENT '地址栏',
  `param` longtext COMMENT '参数值',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `date` varchar(200) DEFAULT NULL COMMENT '日期',
  `visit_url` text COMMENT '域名+参数',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COMMENT='管理员日志';

DROP TABLE cmf_base_balance;

CREATE TABLE `cmf_base_balance` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `identity_type` varchar(255) DEFAULT 'member' COMMENT '身份类型',
  `type` tinyint(6) DEFAULT NULL COMMENT '类型:1=收入,2=支出',
  `price` decimal(10,2) DEFAULT NULL COMMENT '变动金额',
  `before` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更前',
  `after` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更后',
  `content` varchar(50) DEFAULT NULL COMMENT '变动说明',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `order_type` int(11) DEFAULT '0' COMMENT '订单类型 ',
  `order_num` varchar(100) DEFAULT NULL COMMENT '订单单号',
  `order_id` int(11) DEFAULT '0' COMMENT '订单ID',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COMMENT='会员账户余额变动记录';




DROP TABLE cmf_base_config;

CREATE TABLE `cmf_base_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'group_id只',
  `is_menu` tinyint(4) DEFAULT '2' COMMENT '是否菜单1:线上显示,本地都显示,2所有不显示,3本地显示,线上不显示',
  `menu_name` varchar(255) DEFAULT NULL COMMENT '菜单名字',
  `key` bigint(20) DEFAULT NULL COMMENT 'group_id值',
  `group_id` bigint(20) DEFAULT NULL COMMENT '分组ID',
  `name` varchar(100) DEFAULT NULL COMMENT '参数名',
  `value` text COMMENT '参数值,序列化数据',
  `label` varchar(100) DEFAULT NULL COMMENT '参数说明',
  `uridata` varchar(100) DEFAULT NULL COMMENT '附加数据',
  `data` varchar(2555) DEFAULT NULL COMMENT '数据源',
  `type` varchar(100) DEFAULT 'text' COMMENT '设置类型 ',
  `about` varchar(100) DEFAULT NULL COMMENT '备注注释',
  `list_order` bigint(20) DEFAULT NULL COMMENT '排序',
  `status` tinyint(100) DEFAULT '1' COMMENT '0不显示',
  `scatter` varchar(100) DEFAULT NULL COMMENT '隔断,打散数据 /',
  `data_type` varchar(50) DEFAULT NULL COMMENT '数据类型',
  `is_label` tinyint(4) DEFAULT '0' COMMENT '组件数据格式:0否,1是',
  `is_show` tinyint(4) DEFAULT '1' COMMENT '显示:0否,1是',
  `is_edit` tinyint(4) DEFAULT '0' COMMENT '组件数据格式:0否,1是',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=189 DEFAULT CHARSET=utf8mb4 COMMENT='系统配置';

INSERT INTO cmf_base_config VALUES("1","1","系统配置","100","0","system_configuration","","系统配置","","s:0:\"\";","text","","100","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("2","3","私有配置","999999","0","private_configuration","","私有配置","","s:0:\"\";","text","","999999","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("100","2","","0","100","app_logo","s:62:\"dzam1000/default/20241121/c2f8fc5e6f8a082d32591c6337ae427f.png\";","应用LOGO","","s:0:\"\";","img","","1","1","","string","0","1","0");
INSERT INTO cmf_base_config VALUES("101","2","","0","100","app_name","s:12:\"按摩模板\";","应用名称","","s:0:\"\";","","","2","1","","string","0","1","0");
INSERT INTO cmf_base_config VALUES("102","2","","0","999999","domain_name","s:31:\"https://dzam10000.wxselling.net\";","域名","","s:0:\"\";","text","","100","1","","string","0","1","0");
INSERT INTO cmf_base_config VALUES("103","2","","0","100","app_expiration_time","s:16:\"2043-04-30 00:00\";","应用到期时间","","s:0:\"\";","date","开发应用到期时间","300","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("104","2","","0","999999","project_name","s:12:\"按摩模板\";","项目名字","","s:0:\"\";","","本地项目名","300","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("105","2","","0","999999","copyright","s:42:\"技术支持：微巨宝科技有限公司\";","版权","","s:0:\"\";","","登录页版权","400","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("106","2","","0","999999","local_domain_name","s:21:\"http://make10000.ikun\";","本地域名","","s:0:\"\";","","","200","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("107","2","","0","999999","log_file_days","s:2:\"10\";","日志文件保留天数","","s:0:\"\";","number","日志文件保留天数","500","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("136","1","协议管理","200","0","protocol_management","","协议管理","","s:0:\"\";","","","200","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("137","2","","0","200","taboo_instructions","s:3212:\"<p><span style=\"color: rgba(0, 0, 0, 0.85); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);\">禁忌说明:</span></p><p><span style=\"color: rgba(0, 0, 0, 0.85); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);\">服务紧禁忌</span></p><p><span style=\"color: rgba(0, 0, 0, 0.85); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);\">1、饭后半小时不宜进行按摩</span></p><p><span style=\"color: rgba(0, 0, 0, 0.85); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);\">2、妇女经期或妊娠期不宜做腹部、腰部按摩</span></p><p><span style=\"color: rgba(0, 0, 0, 0.85); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);\">3、骨折复位、开放性骨折，人体内有金属固定物禁用</span></p><p><span style=\"color: rgba(0, 0, 0, 0.85); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);\">4、感染性疾病、如骨核、骨髓炎禁用</span></p><p><span style=\"color: rgba(0, 0, 0, 0.85); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);\">5、皮肤病、皮肤破损者（如疤诊、瘟诊、浓重蜂窝组织炎、烧伤、烫伤者）禁用</span></p><p><span style=\"color: rgba(0, 0, 0, 0.85); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);\">6、需要外科手术者禁用</span></p><p><span style=\"color: rgba(0, 0, 0, 0.85); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);\">7、其他严重疾病或诊断不明的较严重疾病禁用&nbsp;</span></p><p><span style=\"color: rgba(0, 0, 0, 0.85); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);\">8、眼部疾病患病期、近期做过眼部手术或做过填充的禁用</span></p>\";","禁忌说明","","s:0:\"\";","content","","100","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("138","2","","0","200","order_notice","s:333:\"<p><span style=\"color: rgba(0, 0, 0, 0.85); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);\">下单须知:</span></p><p><br/></p><p style=\"text-align: right;\"><br/></p>\";","下单须知","","s:0:\"\";","content","","200","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("139","2","","0","999999","automatically_cancel_orders","s:2:\"15\";","自动取消订单","","s:0:\"\";","number","用户n分钟不支付自动取消订单","600","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("140","2","","0","200","entry_agreement","s:31:\"<p>入驻协议</p><p><br/></p>\";","入驻协议","","s:0:\"\";","content","","300","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("141","2","","0","200","contract_management","s:36:\"<p>合同管理<br/></p><p><br/></p>\";","合同管理","","s:0:\"\";","content","","400","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("142","2","","0","999999","the_earliest_appointment_time","s:5:\"00:00\";","预约最早时间","","s:0:\"\";","time","预约最早时间","700","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("143","2","","0","999999","latest_appointment_time","s:5:\"23:50\";","预约最晚时间","","s:0:\"\";","time","预约最晚时间","800","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("144","2","","0","999999","interval_time","s:2:\"10\";","间隔时间","","s:0:\"\";","number","间隔时间(分钟)","900","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("145","2","","0","999999","taxi_time","s:2:\"30\";","打车时间","","s:0:\"\";","number","下单必须n分钟之后,给技师打车时间算上(分钟)","1000","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("146","2","","0","999999","technician_cancels_order","s:2:\"30\";","技师取消订单","","s:0:\"\";","number","技师n分钟不接单自动取消订单","1100","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("147","2","","0","999999","appointment_date","s:1:\"3\";","预约日期","","s:0:\"\";","number","生成预约日期,限制天数","1200","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("148","2","","0","800","invitation_link","s:36:\"/h5/#/pages/index/index?invite_code=\";","邀请链接","","s:0:\"\";","","非开发人员请勿操作","1300","1","","","0","1","1");
INSERT INTO cmf_base_config VALUES("149","2","","0","800","invitation_code_prompt_text","s:90:\"温馨提示:成为分销员邀请好友下单得10%返现，推荐技师入驻可得30元\";","邀请码提示文字","","s:0:\"\";","textarea","修改佣金后这里需要手动同步下,如换行推广图自动换行","550","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("150","2","","0","200","service_agreement","s:24:\"<p>服务协议<br/></p>\";","服务协议","","s:0:\"\";","content","","500","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("153","2","","0","900","lower_level_commission","s:2:\"10\";","下级下单可得佣金","","s:0:\"\";","number","下级下单订单佣金(%)","300","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("154","2","","0","800","number_of_technicians","s:1:\"1\";","技师完成单数","","s:0:\"\";","number","邀请技师,技师完成n单,上级可得n元","400","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("155","2","","0","800","technician_commission","s:2:\"30\";","邀请技师可得佣金","","s:0:\"\";","number","邀请技师完成n单,可得佣金","500","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("156","3","技师结算佣金","300","0","technician_settlement_commission","","技师结算佣金","","s:0:\"\";","","","1000","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("157","2","","0","300","settlement_from_1st_to_10th","s:7:\"1-10/11\";","1-10号结算","","s:0:\"\";","","每月1-10号结算佣金/11号结算","100","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("158","2","","0","300","settlement_on_the_11th_and_21th","s:8:\"11-20/21\";","11-20号结算","","s:0:\"\";","","每月11-20号结算佣金/21号结算","200","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("159","2","","0","300","settlement_on_the_21st_to_31st","s:7:\"21-31/1\";","21-31号结算","","s:0:\"\";","","每月21-31号结算佣金/1号结算","300","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("160","2","","0","100","customer_service_link","s:8:\"wwwwwwww\";","客服链接","","s:0:\"\";","","","600","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("161","2","","0","200","privacy_policy","s:24:\"<p>隐私政策<br/></p>\";","隐私政策","","s:0:\"\";","content","","600","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("162","2","","0","200","user_agreement","s:19:\"<p>用户协议</p>\";","用户协议","","s:0:\"\";","content","","700","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("163","2","","0","999999","withdrawal_time","s:110:\"1/2/3/4/5/6/7/8/9/10/11/12/13/14/15/16/17/18/19/20/21/22/23/24/25/26/27/28/29/30/31/01/02/03/04/05/06/07/08/09\";","提现时间","","s:0:\"\";","","","1500","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("164","1","误工费配置","400","0","cost_allocation_for_lost_work","","误工费配置","","s:0:\"\";","","","400","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("165","2","","0","999999","user_cancels_minutes","s:1:\"5\";","用户未超预约时间","","s:0:\"\";","number","顾客下单后超过预约时间n分钟内免费取消","100","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("166","2","","0","400","user_exceeded_reserved_minute","s:2:\"20\";","用户超预约时间","","s:0:\"\";","number","如超过预约时间n分钟以上且技师已点击接单和已出发按钮需要扣费","200","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("167","2","","0","400","error_fee","s:2:\"30\";","误工费","","s:0:\"\";","number","误工费订单的n%","300","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("168","2","","0","400","user_cancellation_instructions","s:222:\"顾客下单后在未到预约时间内无论技师出发与否 免费取消.如超过预约时间5分钟以上且技师已点击接单和已出发按钮.如因顾客个人原因取消订单需扣除百分之30的误工费\";","用户取消说明","","s:0:\"\";","textarea","","400","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("169","2","","0","100","notify_the_administrator","s:11:\"111/1121212\";","通知管理员","","s:0:\"\";","textarea","技师入驻,通知管理员(手机号)","700","1","/","","0","0","0");
INSERT INTO cmf_base_config VALUES("170","1","路费管理","500","0","toll_management","","路费管理","","s:0:\"\";","","","500","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("171","2","","0","500","starting_price","s:1:\"8\";","起步价","","s:0:\"\";","number","打车的起步价","100","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("172","2","","0","500","per_kilometer","s:1:\"2\";","每公里n元","","s:0:\"\";","number","超过1公里加价n元","200","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("173","2","","0","500","introduction_to_travel_expenses","s:33:\"起步价8元,超出每公里2元\";","路费介绍","","s:0:\"\";","textarea","","300","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("174","3","程序配置","600","0","program_configuration","","程序配置","","s:0:\"\";","","","999998","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("175","2","","0","600","program_information","s:12:\"肃肃上门\";","程序信息","","s:0:\"\";","","","100","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("176","2","","0","600","program_code","s:61:\"dzkf346/default/20241016/cd7169c38bdd10a628a79b85f4d68934.jpg\";","程序码","","s:0:\"\";","img","","200","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("177","2","","0","700","official_account_template_message","s:10:\"**********\";","新订单通知技师模板消息","","s:0:\"\";","","公众号模板消息,模板id","1400","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("178","1","公众号模板配置","700","0","official_account_template_configuration","","公众号模板配置","","s:0:\"\";","","","700","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("179","2","","0","700","alarm_official_account_notice","s:10:\"**********\";","报警公众号通知","","s:0:\"\";","","公众号模板消息,模板id","1500","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("180","2","","0","700","alarm_notification_administrator","s:3:\"1,2\";","报警通知管理员","","s:0:\"\";","textarea","用户id,使用逗号隔开","1600","1",",","","0","1","0");
INSERT INTO cmf_base_config VALUES("181","2","","0","500","free_travel_kilometers","s:1:\"1\";","免费出行公里数","","s:0:\"\";","number","n公里内免费出行","50","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("182","2","","0","999999","gaode_map_key","s:32:\"519a8b21024bd9c2f3b49ebe259a515b\";","高德地图key","","s:0:\"\";","","用于地图标点","1600","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("183","2","","0","999999","tencent_map_key","s:35:\"GGVBZ-DUV6J-N33FQ-FX3AE-HTJ56-N6FDP\";","腾讯地图key","","s:0:\"\";","","用于地图转经纬度,经纬度转地址","1700","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("184","1","邀请技师配置","800","0","invite_technicians_to_configure","","邀请技师配置","","s:0:\"\";","","","800","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("185","1","分销员配置","900","0","distributor_configuration","","分销员配置","","s:0:\"\";","","","900","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("186","2","","0","900","order_required_consume","s:4:\"1000\";","需有效下单消费n元","","s:0:\"\";","number","有效下单金额满足n元后成为分销员","100","1","","","0","1","0");
INSERT INTO cmf_base_config VALUES("187","2","","0","100","additional_commission","s:1:\"2\";","加钟佣金","","a:2:{i:0;a:2:{s:5:\"value\";s:1:\"1\";s:4:\"name\";s:6:\"开启\";}i:1;a:2:{s:5:\"value\";s:1:\"2\";s:4:\"name\";s:6:\"关闭\";}}","radio","加钟是否发放佣金","800","1","","","0","0","0");
INSERT INTO cmf_base_config VALUES("188","2","","0","100","add_clock_plate","s:5:\"false\";","加钟板块","","a:2:{i:0;a:2:{s:5:\"value\";s:4:\"true\";s:4:\"name\";s:6:\"开启\";}i:1;a:2:{s:5:\"value\";s:5:\"false\";s:4:\"name\";s:6:\"关闭\";}}","radio","开启加钟功能","900","1","","","0","0","0");



DROP TABLE cmf_base_leave;

CREATE TABLE `cmf_base_leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户',
  `username` varchar(255) DEFAULT NULL COMMENT '联系人',
  `phone` varchar(255) DEFAULT NULL COMMENT '手机号',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `content` varchar(2555) DEFAULT NULL COMMENT '留言内容',
  `images` text COMMENT '图集',
  `reply_content` varchar(255) DEFAULT NULL COMMENT '回复内容',
  `reply_time` bigint(20) DEFAULT NULL COMMENT '回复时间',
  `create_time` bigint(20) DEFAULT '0' COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='投诉建议';




DROP TABLE cmf_base_point;

CREATE TABLE `cmf_base_point` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `identity_type` varchar(255) DEFAULT 'member' COMMENT '身份类型',
  `type` tinyint(6) DEFAULT NULL COMMENT '类型:1=收入,2=支出',
  `price` decimal(10,2) DEFAULT NULL COMMENT '变动金额',
  `before` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更前',
  `after` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更后',
  `content` varchar(50) DEFAULT NULL COMMENT '变动说明',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `order_type` int(11) DEFAULT '0' COMMENT '订单类型 ',
  `order_num` varchar(100) DEFAULT NULL COMMENT '订单单号',
  `order_id` int(11) DEFAULT '0' COMMENT '订单ID',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  `child_id` int(11) DEFAULT NULL COMMENT '关联下级id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COMMENT='会员—积分';




CREATE TABLE `cmf_base_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `a_image` varchar(255) DEFAULT NULL,
  `images` text,
  `a_images` text,
  `file` varchar(255) DEFAULT NULL,
  `a_file` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `a_video` varchar(255) DEFAULT NULL,
  `is_index` tinyint(4) DEFAULT '1' COMMENT '首页推荐:1是,2否',
  `type` tinyint(4) DEFAULT '1' COMMENT '类型:1普通商品,2抢购商品,3拼团商品',
  `is_pay` tinyint(4) DEFAULT '1' COMMENT '支付:1是,2否',
  `content` text,
  `introduce` varchar(255) DEFAULT NULL COMMENT '介绍',
  `pay_type` tinyint(4) DEFAULT '1' COMMENT '支付类型:1微信,2余额,3支付宝',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态:1审核中,2已通过,3已拒绝',
  `refuse` varchar(255) DEFAULT NULL COMMENT '拒绝理由',
  `cancel_time` bigint(20) DEFAULT NULL COMMENT '取消时间',
  `pass_time` bigint(20) DEFAULT NULL COMMENT '通过时间',
  `refuse_time` bigint(20) DEFAULT NULL COMMENT '拒绝时间',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE cmf_base_withdrawal;

CREATE TABLE `cmf_base_withdrawal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户信息',
  `type` tinyint(2) DEFAULT '1' COMMENT '提现类型:1支付宝,2微信',
  `identity_type` varchar(255) DEFAULT 'member' COMMENT '身份类型',
  `openid` varchar(120) DEFAULT NULL COMMENT 'openid',
  `price` decimal(10,2) DEFAULT NULL COMMENT '提现金额',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态:1待审核,2已审核,3已拒绝',
  `refuse` varchar(50) DEFAULT '' COMMENT '拒绝原因',
  `charges` decimal(10,2) DEFAULT '0.00' COMMENT '手续费',
  `ali_username` varchar(25) DEFAULT NULL COMMENT '支付宝用户名字',
  `ali_account` varchar(25) DEFAULT NULL COMMENT '支付宝账号',
  `order_num` varchar(100) DEFAULT NULL COMMENT '订单号',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='会员提现申请';

INSERT INTO cmf_base_withdrawal VALUES("1","12","1","member","owLnu6YMPUR5Q_GFzzc1MDfSw4_0","1000.00","2","","0.00","纪祥","18633550607","2409088102950067361742","1725781029","1726652481","0");



DROP TABLE cmf_comment;

CREATE TABLE `cmf_comment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '被回复的评论id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发表评论的用户id',
  `to_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '被评论的用户id',
  `object_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论内容 id',
  `like_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '点赞数',
  `dislike_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '不喜欢数',
  `floor` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '楼层数',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论时间',
  `delete_time` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:已审核,0:未审核',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '评论类型；1实名评论',
  `table_name` varchar(64) NOT NULL DEFAULT '' COMMENT '评论内容所在表，不带表前缀',
  `full_name` varchar(50) NOT NULL DEFAULT '' COMMENT '评论者昵称',
  `email` varchar(255) NOT NULL DEFAULT '' COMMENT '评论者邮箱',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '层级关系',
  `url` text COMMENT '原文地址',
  `content` text CHARACTER SET utf8mb4 COMMENT '评论内容',
  `more` text CHARACTER SET utf8mb4 COMMENT '扩展属性',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `table_id_status` (`table_name`,`object_id`,`status`) USING BTREE,
  KEY `object_id` (`object_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `parent_id` (`parent_id`) USING BTREE,
  KEY `create_time` (`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='评论表';




DROP TABLE cmf_commission_log;

CREATE TABLE `cmf_commission_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `technician_id` int(10) DEFAULT NULL COMMENT '技师id',
  `date` varchar(255) DEFAULT NULL COMMENT '日期',
  `day` varchar(255) DEFAULT NULL COMMENT '天',
  `commission` varchar(255) DEFAULT NULL COMMENT '佣金比例',
  `goods_amount` varchar(255) DEFAULT NULL COMMENT '商品金额',
  `freight_amount` varchar(255) DEFAULT NULL COMMENT '车费',
  `total_amount` varchar(255) DEFAULT NULL COMMENT '总订单金额',
  `amount` varchar(255) DEFAULT NULL COMMENT '总佣金',
  `create_time` bigint(20) DEFAULT NULL COMMENT '下单时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='结算记录';




DROP TABLE cmf_express;

CREATE TABLE `cmf_express` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(12) DEFAULT NULL COMMENT '快递名称',
  `abbr` varchar(10) DEFAULT NULL COMMENT '微信快递code',
  `kd_hundred_code` varchar(255) DEFAULT NULL COMMENT '快递100code',
  `kd_bird_code` varchar(255) DEFAULT NULL COMMENT '快递鸟code',
  `status` tinyint(4) DEFAULT '1' COMMENT '2删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COMMENT='快递表';

INSERT INTO cmf_express VALUES("1","安能物流","ANE","annengwuliu","ANE","1");
INSERT INTO cmf_express VALUES("2","百世快递","BEST","huitongkuaidi","HTKY","1");
INSERT INTO cmf_express VALUES("3","德邦快递","DB","debangkuaidi","DBL","1");
INSERT INTO cmf_express VALUES("4","中国邮政速递物流","EMS","youzhengguonei","YZPY","1");
INSERT INTO cmf_express VALUES("6","京东快递","JDL","jd","JD","1");
INSERT INTO cmf_express VALUES("7","极兔快递","JTSD","jtexpress","JTSD","1");
INSERT INTO cmf_express VALUES("9","顺丰速运","SF","shunfeng","SF","1");
INSERT INTO cmf_express VALUES("10","申通快递","STO","shentong","STO","1");
INSERT INTO cmf_express VALUES("12","圆通速递","YTO","yuantong","YTO","1");
INSERT INTO cmf_express VALUES("13","韵达快递","YUNDA","yunda","YD","1");
INSERT INTO cmf_express VALUES("14","中通快递","ZTO","zhongtong","ZTO","1");



DROP TABLE cmf_form_model;

CREATE TABLE `cmf_form_model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `json_params` text COLLATE utf8_unicode_ci,
  `type` tinyint(2) DEFAULT '1' COMMENT '1提交数据  2访问域名',
  `remark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=86 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='生成curt';




DROP TABLE cmf_hook;

CREATE TABLE `cmf_hook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '钩子类型(1:系统钩子;2:应用钩子;3:模板钩子;4:后台模板钩子)',
  `once` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否只允许一个插件运行(0:多个;1:一个)',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `hook` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子',
  `app` varchar(15) NOT NULL DEFAULT '' COMMENT '应用名(只有应用钩子才用)',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COMMENT='系统钩子表';

INSERT INTO cmf_hook VALUES("2","1","0","应用开始","app_begin","cmf","应用开始");
INSERT INTO cmf_hook VALUES("3","1","0","模块初始化","module_init","cmf","模块初始化");
INSERT INTO cmf_hook VALUES("4","1","0","控制器开始","action_begin","cmf","控制器开始");
INSERT INTO cmf_hook VALUES("5","1","0","视图输出过滤","view_filter","cmf","视图输出过滤");
INSERT INTO cmf_hook VALUES("6","1","0","应用结束","app_end","cmf","应用结束");
INSERT INTO cmf_hook VALUES("7","1","0","日志write方法","log_write","cmf","日志write方法");
INSERT INTO cmf_hook VALUES("8","1","0","输出结束","response_end","cmf","输出结束");
INSERT INTO cmf_hook VALUES("9","1","0","后台控制器初始化","admin_init","cmf","后台控制器初始化");
INSERT INTO cmf_hook VALUES("10","1","0","前台控制器初始化","home_init","cmf","前台控制器初始化");
INSERT INTO cmf_hook VALUES("11","1","1","发送手机验证码","send_mobile_verification_code","cmf","发送手机验证码");
INSERT INTO cmf_hook VALUES("12","3","0","模板 body标签开始","body_start","","模板 body标签开始");
INSERT INTO cmf_hook VALUES("13","3","0","模板 head标签结束前","before_head_end","","模板 head标签结束前");
INSERT INTO cmf_hook VALUES("14","3","0","模板底部开始","footer_start","","模板底部开始");
INSERT INTO cmf_hook VALUES("15","3","0","模板底部开始之前","before_footer","","模板底部开始之前");
INSERT INTO cmf_hook VALUES("16","3","0","模板底部结束之前","before_footer_end","","模板底部结束之前");
INSERT INTO cmf_hook VALUES("17","3","0","模板 body 标签结束之前","before_body_end","","模板 body 标签结束之前");
INSERT INTO cmf_hook VALUES("18","3","0","模板左边栏开始","left_sidebar_start","","模板左边栏开始");
INSERT INTO cmf_hook VALUES("19","3","0","模板左边栏结束之前","before_left_sidebar_end","","模板左边栏结束之前");
INSERT INTO cmf_hook VALUES("20","3","0","模板右边栏开始","right_sidebar_start","","模板右边栏开始");
INSERT INTO cmf_hook VALUES("21","3","0","模板右边栏结束之前","before_right_sidebar_end","","模板右边栏结束之前");
INSERT INTO cmf_hook VALUES("22","3","1","评论区","comment","","评论区");
INSERT INTO cmf_hook VALUES("23","3","1","留言区","guestbook","","留言区");
INSERT INTO cmf_hook VALUES("24","2","0","后台首页仪表盘","admin_dashboard","admin","后台首页仪表盘");
INSERT INTO cmf_hook VALUES("25","4","0","后台模板 head标签结束前","admin_before_head_end","","后台模板 head标签结束前");
INSERT INTO cmf_hook VALUES("26","4","0","后台模板 body 标签结束之前","admin_before_body_end","","后台模板 body 标签结束之前");
INSERT INTO cmf_hook VALUES("27","2","0","后台登录页面","admin_login","admin","后台登录页面");
INSERT INTO cmf_hook VALUES("28","1","1","前台模板切换","switch_theme","cmf","前台模板切换");
INSERT INTO cmf_hook VALUES("29","3","0","主要内容之后","after_content","","主要内容之后");
INSERT INTO cmf_hook VALUES("32","2","1","获取上传界面","fetch_upload_view","user","获取上传界面");
INSERT INTO cmf_hook VALUES("33","3","0","主要内容之前","before_content","cmf","主要内容之前");
INSERT INTO cmf_hook VALUES("34","1","0","日志写入完成","log_write_done","cmf","日志写入完成");
INSERT INTO cmf_hook VALUES("35","1","1","后台模板切换","switch_admin_theme","cmf","后台模板切换");
INSERT INTO cmf_hook VALUES("36","1","1","验证码图片","captcha_image","cmf","验证码图片");
INSERT INTO cmf_hook VALUES("37","2","1","后台模板设计界面","admin_theme_design_view","admin","后台模板设计界面");
INSERT INTO cmf_hook VALUES("38","2","1","后台设置网站信息界面","admin_setting_site_view","admin","后台设置网站信息界面");
INSERT INTO cmf_hook VALUES("39","2","1","后台清除缓存界面","admin_setting_clear_cache_view","admin","后台清除缓存界面");
INSERT INTO cmf_hook VALUES("40","2","1","后台导航管理界面","admin_nav_index_view","admin","后台导航管理界面");
INSERT INTO cmf_hook VALUES("41","2","1","后台友情链接管理界面","admin_link_index_view","admin","后台友情链接管理界面");
INSERT INTO cmf_hook VALUES("42","2","1","后台幻灯片管理界面","admin_slide_index_view","admin","后台幻灯片管理界面");
INSERT INTO cmf_hook VALUES("43","2","1","后台管理员列表界面","admin_user_index_view","admin","后台管理员列表界面");
INSERT INTO cmf_hook VALUES("44","2","1","后台角色管理界面","admin_rbac_index_view","admin","后台角色管理界面");
INSERT INTO cmf_hook VALUES("49","2","1","用户管理本站用户列表界面","user_admin_index_view","user","用户管理本站用户列表界面");
INSERT INTO cmf_hook VALUES("50","2","1","资源管理列表界面","user_admin_asset_index_view","user","资源管理列表界面");
INSERT INTO cmf_hook VALUES("51","2","1","用户管理第三方用户列表界面","user_admin_oauth_index_view","user","用户管理第三方用户列表界面");
INSERT INTO cmf_hook VALUES("52","2","1","后台首页界面","admin_index_index_view","admin","后台首页界面");
INSERT INTO cmf_hook VALUES("53","2","1","后台回收站界面","admin_recycle_bin_index_view","admin","后台回收站界面");
INSERT INTO cmf_hook VALUES("54","2","1","后台菜单管理界面","admin_menu_index_view","admin","后台菜单管理界面");
INSERT INTO cmf_hook VALUES("55","2","1","后台自定义登录是否开启钩子","admin_custom_login_open","admin","后台自定义登录是否开启钩子");
INSERT INTO cmf_hook VALUES("64","2","1","后台幻灯片页面列表界面","admin_slide_item_index_view","admin","后台幻灯片页面列表界面");
INSERT INTO cmf_hook VALUES("65","2","1","后台幻灯片页面添加界面","admin_slide_item_add_view","admin","后台幻灯片页面添加界面");
INSERT INTO cmf_hook VALUES("66","2","1","后台幻灯片页面编辑界面","admin_slide_item_edit_view","admin","后台幻灯片页面编辑界面");
INSERT INTO cmf_hook VALUES("67","2","1","后台管理员添加界面","admin_user_add_view","admin","后台管理员添加界面");
INSERT INTO cmf_hook VALUES("68","2","1","后台管理员编辑界面","admin_user_edit_view","admin","后台管理员编辑界面");
INSERT INTO cmf_hook VALUES("69","2","1","后台角色添加界面","admin_rbac_role_add_view","admin","后台角色添加界面");
INSERT INTO cmf_hook VALUES("70","2","1","后台角色编辑界面","admin_rbac_role_edit_view","admin","后台角色编辑界面");
INSERT INTO cmf_hook VALUES("71","2","1","后台角色授权界面","admin_rbac_authorize_view","admin","后台角色授权界面");



DROP TABLE cmf_hook_plugin;

CREATE TABLE `cmf_hook_plugin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态(0:禁用,1:启用)',
  `hook` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子名',
  `plugin` varchar(50) NOT NULL DEFAULT '' COMMENT '插件',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COMMENT='系统钩子插件表';

INSERT INTO cmf_hook_plugin VALUES("2","10000","1","app_begin","Configs");
INSERT INTO cmf_hook_plugin VALUES("3","10000","1","fetch_upload_view","Oss");
INSERT INTO cmf_hook_plugin VALUES("4","10000","1","admin_init","AdminJournal");
INSERT INTO cmf_hook_plugin VALUES("5","10000","1","admin_login","FengiyLogin");
INSERT INTO cmf_hook_plugin VALUES("6","10000","1","send_mobile_verification_code","TencentcloudSms");



DROP TABLE cmf_like;

CREATE TABLE `cmf_like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `create_time` bigint(20) DEFAULT '0' COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `user_id` (`user_id`,`pid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='收藏';




DROP TABLE cmf_link;

CREATE TABLE `cmf_link` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态;1:显示;0:不显示',
  `rating` int(11) NOT NULL DEFAULT '0' COMMENT '友情链接评级',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '友情链接描述',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '友情链接地址',
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '友情链接名称',
  `image` varchar(100) NOT NULL DEFAULT '' COMMENT '友情链接图标',
  `target` varchar(10) NOT NULL DEFAULT '' COMMENT '友情链接打开方式',
  `rel` varchar(50) NOT NULL DEFAULT '' COMMENT '链接与网站的关系',
  `cate_id` int(11) DEFAULT '0' COMMENT '链接分类',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='友情链接表';

INSERT INTO cmf_link VALUES("1","0","1","200","小程序首页","/pages/index/index","首页","admin/20230218/64aab5da8de3c18e39354a90b4efa5be.png","_blank","","0");
INSERT INTO cmf_link VALUES("2","0","0","100","","/pages/user/index","个人中心","","","","0");



DROP TABLE cmf_link_category;

CREATE TABLE `cmf_link_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '幻灯片分类',
  `remark` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '分类备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='链接分类';

INSERT INTO cmf_link_category VALUES("1","小程序链接","");
INSERT INTO cmf_link_category VALUES("2","其他","");



DROP TABLE cmf_member;

CREATE TABLE `cmf_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(30) DEFAULT NULL COMMENT '昵称',
  `avatar` varchar(200) DEFAULT NULL COMMENT '头像',
  `openid` varchar(80) DEFAULT NULL COMMENT 'openid',
  `phone` varchar(15) DEFAULT NULL COMMENT '手机号',
  `pass` varchar(100) DEFAULT NULL COMMENT '密码',
  `balance` decimal(11,2) DEFAULT '0.00' COMMENT '余额',
  `point` decimal(11,2) DEFAULT '0.00' COMMENT '积分',
  `ip` varchar(255) DEFAULT NULL COMMENT '登录ip地址',
  `login_time` bigint(20) DEFAULT NULL COMMENT '最后登录时间',
  `login_city` varchar(255) DEFAULT NULL COMMENT '登录城市',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  `invite_code` varchar(255) DEFAULT NULL COMMENT '邀请码',
  `invite_image` varchar(255) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL COMMENT '上级',
  `effective_invitation` tinyint(4) DEFAULT '2' COMMENT '是否有效邀请:1是,2否',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

INSERT INTO cmf_member VALUES("1","测试人员","https://thirdwx.qlogo.cn/mmopen/vi_32/qeicaibWhcOoLJ9C9przNBZtAMOsKdrLCWa7pbIeq2zVmtshic2ghCRVGzSNgmxjGtjheCnz7cIe4Nszg6a5zGhDZwqtDrajqrelYK8vjIictE4/132","1","","","0.00","0.00","123.14.174.139","1735298609","","1735298609","","0","n8ktyey7","","0","2");



DROP TABLE cmf_member_gzh;

CREATE TABLE `cmf_member_gzh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `openid` varchar(80) DEFAULT NULL COMMENT 'openid',
  `unionid` varchar(255) DEFAULT NULL COMMENT 'unionId',
  `ext` text CHARACTER SET utf8 COMMENT '扩展信息',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='公众号用户';




DROP TABLE cmf_member_recharge;

CREATE TABLE `cmf_member_recharge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `price` decimal(10,2) DEFAULT NULL COMMENT '价格',
  `balance` decimal(10,2) DEFAULT NULL COMMENT '充值余额',
  `give_balance` decimal(10,2) DEFAULT NULL COMMENT '赠送余额',
  `list_order` int(11) DEFAULT '1000',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='充值管理';




DROP TABLE cmf_member_recharge_order;

CREATE TABLE `cmf_member_recharge_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `recharge_id` int(11) DEFAULT NULL,
  `order_num` varchar(255) DEFAULT NULL COMMENT '订单号',
  `amount` varchar(255) DEFAULT NULL COMMENT '支付金额',
  `is_pay` tinyint(4) DEFAULT '1' COMMENT '支付:1否,2是',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态:1未支付,2已支付,3申请退款',
  `pay_time` bigint(20) DEFAULT NULL COMMENT '支付时间',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  `balance` decimal(10,2) DEFAULT NULL COMMENT '充值余额',
  `give_balance` decimal(10,2) DEFAULT NULL COMMENT '赠送余额',
  `total_balance` decimal(10,2) DEFAULT NULL COMMENT '总充值金额',
  `pid` int(11) DEFAULT NULL COMMENT '上级id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='充值订单';




DROP TABLE cmf_openid;

CREATE TABLE `cmf_openid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `openid` varchar(255) DEFAULT NULL,
  `identity_type` varchar(255) DEFAULT NULL COMMENT '身份类型',
  `create_time` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO cmf_openid VALUES("1","1","1","member","1730096091");



DROP TABLE cmf_option;

CREATE TABLE `cmf_option` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `autoload` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '是否自动加载;1:自动加载;0:不自动加载',
  `option_name` varchar(64) NOT NULL DEFAULT '' COMMENT '配置名',
  `option_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '配置值',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `option_name` (`option_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='全站配置表';

INSERT INTO cmf_option VALUES("1","1","site_info","{\"site_name\":\"微巨宝定制后台模板\",\"site_seo_title\":\"微巨宝定制后台模板\",\"site_seo_keywords\":\"\",\"site_seo_description\":\"\"}");
INSERT INTO cmf_option VALUES("2","1","set_config","{\"app_name\":\"按摩模板\",\"app_logo\":\"dzam1000\\/default\\/20241121\\/c2f8fc5e6f8a082d32591c6337ae427f.png\",\"user_agreement\":\"&lt;p&gt;用户协议&lt;\\/p&gt;\",\"privacy_agreement\":\"&lt;p&gt;&lt;span style=&quot;color: rgba(0, 0, 0, 0.85); font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, &amp;quot;PingFang SC&amp;quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; background-color: rgb(255, 255, 255);&quot;&gt;隐私协议&lt;\\/span&gt;&lt;\\/p&gt;\",\"group_id\":\"100\",\"app_logo_1\":\"https:\\/\\/oss.ausite.cn\\/dz000\\/default\\/20230217\\/2680011108c19b50228c124d86749b7d.jpg?watermark\",\"_plugin\":\"configs\",\"_controller\":\"admin_index\",\"_action\":\"index\",\"test\":\"df4w4e8f7e\\/sd4fds4f6sdf\\/4dsf4wef4we\\/sd44fwe54fwe8\\/4f5esf45wef45we\\/4f5we4f5we45ds\\/x4c5f45we7f45weg4e\\/4g5re7hh84r8h4er8\\/h45qwe84f5r\\/4g5w4g8we\\/4s545wef5ew4\",\"domain_name\":\"https:\\/\\/dzam10000.wxselling.net\",\"s\":[\"sdfwe\",\"sfwaweew\"],\"f\":[\"fawefewfawefwe\"],\"debug_mode\":\"1\",\"app_expiration_time\":\"2043-04-30 00:00\",\"listorder\":{\"100\":\"1\",\"101\":\"2\",\"108\":\"100\"},\"label\":{\"101\":\"应用名称\",\"103\":\"应用到期时间\",\"160\":\"客服链接\",\"169\":\"通知管理员\",\"187\":\"加钟佣金\",\"188\":\"加钟板块\"},\"name\":{\"101\":\"app_name\",\"103\":\"app_expiration_time\",\"160\":\"customer_service_link\",\"169\":\"notify_the_administrator\",\"187\":\"additional_commission\",\"188\":\"add_clock_plate\"},\"about\":{\"101\":\"\",\"103\":\"开发应用到期时间\",\"160\":\"\",\"169\":\"技师入驻,通知管理员(手机号)\",\"187\":\"加钟是否发放佣金\",\"188\":\"开启加钟功能\"},\"project_name\":\"按摩模板\",\"copyright\":\"技术支持：微巨宝科技有限公司\",\"local_domain_name\":\"http:\\/\\/make10000.ikun\",\"number_of_days_for_log_files\":\"\",\"log_file_days\":\"10\",\"list_order\":{\"100\":\"1\",\"101\":\"2\",\"103\":\"300\",\"160\":\"600\",\"169\":\"700\",\"187\":\"800\",\"188\":\"900\"},\"video\":\"dzkf00000000001\\/default\\/20240624\\/c2dcc94117717aaad3d7d9664c2affcb.mp4\",\"file2\":\"dzkf00000000001\\/default\\/20240624\\/2cec82e71890d9b59a689e8a869c544e.docx\",\"video2\":\"dzkf00000000001\\/default\\/20240624\\/ab75196b4f0f699eb563758d59e662ca.mp4\",\"file333\":\"dzkf00000000001\\/default\\/20240624\\/9fff193bb6acaead8c8523bea7a76ad6.pdf\",\"taboo_instructions\":\"&lt;p&gt;&lt;span style=&quot;color: rgba(0, 0, 0, 0.85); font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, &amp;quot;PingFang SC&amp;quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);&quot;&gt;禁忌说明:&lt;\\/span&gt;&lt;\\/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgba(0, 0, 0, 0.85); font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, &amp;quot;PingFang SC&amp;quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);&quot;&gt;服务紧禁忌&lt;\\/span&gt;&lt;\\/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgba(0, 0, 0, 0.85); font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, &amp;quot;PingFang SC&amp;quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);&quot;&gt;1、饭后半小时不宜进行按摩&lt;\\/span&gt;&lt;\\/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgba(0, 0, 0, 0.85); font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, &amp;quot;PingFang SC&amp;quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);&quot;&gt;2、妇女经期或妊娠期不宜做腹部、腰部按摩&lt;\\/span&gt;&lt;\\/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgba(0, 0, 0, 0.85); font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, &amp;quot;PingFang SC&amp;quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);&quot;&gt;3、骨折复位、开放性骨折，人体内有金属固定物禁用&lt;\\/span&gt;&lt;\\/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgba(0, 0, 0, 0.85); font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, &amp;quot;PingFang SC&amp;quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);&quot;&gt;4、感染性疾病、如骨核、骨髓炎禁用&lt;\\/span&gt;&lt;\\/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgba(0, 0, 0, 0.85); font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, &amp;quot;PingFang SC&amp;quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);&quot;&gt;5、皮肤病、皮肤破损者（如疤诊、瘟诊、浓重蜂窝组织炎、烧伤、烫伤者）禁用&lt;\\/span&gt;&lt;\\/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgba(0, 0, 0, 0.85); font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, &amp;quot;PingFang SC&amp;quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);&quot;&gt;6、需要外科手术者禁用&lt;\\/span&gt;&lt;\\/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgba(0, 0, 0, 0.85); font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, &amp;quot;PingFang SC&amp;quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);&quot;&gt;7、其他严重疾病或诊断不明的较严重疾病禁用&amp;nbsp;&lt;\\/span&gt;&lt;\\/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgba(0, 0, 0, 0.85); font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, &amp;quot;PingFang SC&amp;quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);&quot;&gt;8、眼部疾病患病期、近期做过眼部手术或做过填充的禁用&lt;\\/span&gt;&lt;\\/p&gt;\",\"order_notice\":\"&lt;p&gt;&lt;span style=&quot;color: rgba(0, 0, 0, 0.85); font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, &amp;quot;PingFang SC&amp;quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; text-wrap: wrap; background-color: rgb(255, 255, 255);&quot;&gt;下单须知:&lt;\\/span&gt;&lt;\\/p&gt;&lt;p&gt;&lt;br\\/&gt;&lt;\\/p&gt;&lt;p style=&quot;text-align: right;&quot;&gt;&lt;br\\/&gt;&lt;\\/p&gt;\",\"automatically_cancel_orders\":\"15\",\"entry_agreement\":\"&lt;p&gt;入驻协议&lt;\\/p&gt;&lt;p&gt;&lt;br\\/&gt;&lt;\\/p&gt;\",\"contract_management\":\"&lt;p&gt;合同管理&lt;br\\/&gt;&lt;\\/p&gt;&lt;p&gt;&lt;br\\/&gt;&lt;\\/p&gt;\",\"the_earliest_appointment_time\":\"00:00\",\"latest_appointment_time\":\"23:50\",\"interval_time\":\"10\",\"taxi_time\":\"30\",\"technician_cancels_order\":\"30\",\"appointment_date\":\"3\",\"invitation_link\":\"\\/h5\\/#\\/pages\\/index\\/index?invite_code=\",\"invitation_code_prompt_text\":\"温馨提示:成为分销员邀请好友下单得10%返现，推荐技师入驻可得30元\",\"service_agreement\":\"&lt;p&gt;服务协议&lt;br\\/&gt;&lt;\\/p&gt;\",\"expected_commission\":\"预计可得佣金\",\"current_performance\":\"当前业绩\",\"lower_level_commission\":\"10\",\"number_of_technicians\":\"1\",\"technician_commission\":\"30\",\"settlement_from_1st_to_10th\":\"1-10\\/11\",\"settlement_on_the_10th_and_20th\":\"\",\"settlement_on_the_11th_and_20th\":\"11-20\\/21\",\"settlement_on_the_21st_to_31st\":\"21-31\\/1\",\"customer_service_link\":\"wwwwwwww\",\"privacy_policy\":\"&lt;p&gt;隐私政策&lt;br\\/&gt;&lt;\\/p&gt;\",\"withdrawal_time\":\"1\\/2\\/3\\/4\\/5\\/6\\/7\\/8\\/9\\/10\\/11\\/12\\/13\\/14\\/15\\/16\\/17\\/18\\/19\\/20\\/21\\/22\\/23\\/24\\/25\\/26\\/27\\/28\\/29\\/30\\/31\\/01\\/02\\/03\\/04\\/05\\/06\\/07\\/08\\/09\",\"user_cancels_minutes\":\"5\",\"the_user_exceeded_the_reserved_minute\":\"\",\"user_exceeded_reserved_minute\":\"20\",\"user_error_fee\":\"\",\"error_fee\":\"30\",\"user_cancellation_instructions\":\"顾客下单后在未到预约时间内无论技师出发与否 免费取消.如超过预约时间5分钟以上且技师已点击接单和已出发按钮.如因顾客个人原因取消订单需扣除百分之30的误工费\",\"notify_the_administrator\":\"111\\/1121212\",\"starting_price\":\"8\",\"n_yuan_per_kilometer\":\"2\",\"per_kilometer\":\"2\",\"introduction_to_travel_expenses\":\"起步价8元,超出每公里2元\",\"program_information\":\"汇悦到家-汇悦到家\",\"program_code\":\"dzkf346\\/default\\/20241016\\/cd7169c38bdd10a628a79b85f4d68934.jpg\",\"is_show\":\"1\",\"show\":{\"app_logo\":\"on\",\"app_name\":\"on\",\"app_expiration_time\":\"on\",\"customer_service_link\":\"on\"},\"official_account_template_message\":\"**********\",\"alarm_official_account_notice\":\"**********\",\"alarm_notification_administrator\":\"1,2\",\"free_travel_kilometers\":\"1\",\"gaode_map_key\":\"519a8b21024bd9c2f3b49ebe259a515b\",\"tencent_map_key\":\"GGVBZ-DUV6J-N33FQ-FX3AE-HTJ56-N6FDP\",\"order_required_to_consume_n_yuan\":\"10\",\"order_required_consume\":\"1000\",\"additional_commission\":\"2\",\"add_clock_plate\":\"false\"}");
INSERT INTO cmf_option VALUES("3","1","storage","{\"storages\":{\"Oss\":{\"name\":\"阿里云OSS存储\",\"driver\":\"\\\\plugins\\\\oss\\\\lib\\\\Oss\"}},\"type\":\"Oss\"}");
INSERT INTO cmf_option VALUES("4","1","weipay","{\"wx_mp_app_id\":\"***\",\"wx_mini_app_id\":\"\",\"wx_mp_app_secret\":\"***\",\"wx_mini_app_secret\":\"\",\"wx_token\":\"\",\"wx_encodingaeskey\":\"\",\"wx_app_id\":\"\",\"wx_mch_id\":\"******\",\"wx_v2_mch_secret_key\":\"Qwertyuiopasdfghjklzxcvbnm123456\",\"wx_v3_mch_secret_key\":\"Qwertyuiopasdfghjklzxcvbnm123456\",\"wx_mch_secret_cert\":\"\",\"wx_mch_public_cert_path\":\"\",\"wx_notify_url\":\"\\/api\\/wxapp\\/notify\\/wxPayNotify\",\"ali_app_id\":\"\",\"ali_app_secret_cert\":\"\",\"ali_app_public_cert_path\":\"\",\"ali_alipay_public_cert_path\":\"\",\"ali_alipay_root_cert_path\":\"\",\"ali_notify_url\":\"\",\"ali_return_url\":\"\",\"wx_system_type\":\"wx_mp\"}");
INSERT INTO cmf_option VALUES("5","1","upload_setting","{\"max_files\":\"20\",\"chunk_size\":\"512\",\"file_types\":{\"image\":{\"upload_max_filesize\":\"10240\",\"extensions\":\"jpg,jpeg,png,gif,bmp4,mp3\"},\"video\":{\"upload_max_filesize\":\"10240\",\"extensions\":\"mp4,avi,wmv,rm,rmvb,mkv\"},\"audio\":{\"upload_max_filesize\":\"10240\",\"extensions\":\"mp3,wma,wav\"},\"file\":{\"upload_max_filesize\":\"10240\",\"extensions\":\"txt,pdf,doc,docx,xls,xlsx,ppt,pptx,zip,rar,pem\"}}}");



DROP TABLE cmf_order_pay;

CREATE TABLE `cmf_order_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `openid` varchar(255) DEFAULT NULL COMMENT 'openid',
  `order_type` int(5) DEFAULT '1' COMMENT '订单类型:',
  `pay_type` tinyint(4) DEFAULT '1' COMMENT '支付类型:1微信支付,2余额支付,3积分支付,4支付宝支付',
  `order_num` varchar(255) DEFAULT NULL COMMENT '关联订单号',
  `pay_num` varchar(255) DEFAULT NULL COMMENT '发起支付单号',
  `trade_num` varchar(255) DEFAULT NULL COMMENT '第三方返回单号',
  `amount` decimal(10,2) DEFAULT NULL COMMENT '支付金额',
  `notify` text COMMENT '回调信息',
  `status` int(2) DEFAULT '1' COMMENT '支付状态:1未支付,2已支付',
  `pay_time` bigint(20) DEFAULT NULL COMMENT '支付时间',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='支付管理';




DROP TABLE cmf_plugin;

CREATE TABLE `cmf_plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '插件类型;1:网站;8:微信',
  `has_admin` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台管理,0:没有;1:有',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态;1:开启;0:禁用',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '插件安装时间',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '插件标识名,英文字母(惟一)',
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '插件名称',
  `demo_url` varchar(50) NOT NULL DEFAULT '' COMMENT '演示地址，带协议',
  `hooks` varchar(255) NOT NULL DEFAULT '' COMMENT '实现的钩子;以“,”分隔',
  `author` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '插件作者',
  `author_url` varchar(50) NOT NULL DEFAULT '' COMMENT '作者网站链接',
  `version` varchar(20) NOT NULL DEFAULT '' COMMENT '插件版本号',
  `description` varchar(255) NOT NULL COMMENT '插件描述',
  `config` text COMMENT '插件配置',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COMMENT='插件表';

INSERT INTO cmf_plugin VALUES("1","1","1","1","1660558216","Weipay","APP信息&支付信息","","","wjb","","1.0.0","微信小程序&公众号&支付宝支付信息","[]");
INSERT INTO cmf_plugin VALUES("2","1","1","1","1660558220","Swagger","Swagger","http://demo.thinkcmf.com","","ThinkCMF","http://www.thinkcmf.com","1.0.0","Swagger","[]");
INSERT INTO cmf_plugin VALUES("4","1","1","1","1660723183","Configs","系统参数设置","","","lampzww","","1.0","config读取配置参数扩展","[]");
INSERT INTO cmf_plugin VALUES("6","1","0","1","1660723194","Oss","OSS上传","","","zsl","","1.0.0","OSS上传","{\"accessKey\":\"LTAI5t9uSAQt9GiYcZ7X34Xe\",\"secretKey\":\"4zgCseVv6ufMsAu2oP1BoK5SFoGOi3\",\"protocol\":\"https\",\"domain\":\"oss.ausite.cn\",\"bucket\":\"twjbdzoss\",\"style_separator\":\"?\",\"dir\":\"dzam1000\"}");
INSERT INTO cmf_plugin VALUES("8","1","1","1","1660723805","Form","表单生成","http://demo.thinkcmf.com","","idcpj","http://www.thinkcmf.com","1.1","表单生成","{\"custom_config\":\"0\",\"text\":\"hello,ThinkCMF!\",\"password\":\"\",\"number\":\"1.0\",\"select\":\"1\",\"checkbox\":1,\"radio\":\"1\",\"radio2\":\"1\",\"textarea\":\"\\u8fd9\\u91cc\\u662f\\u4f60\\u8981\\u586b\\u5199\\u7684\\u5185\\u5bb9\",\"date\":\"2017-05-20\",\"datetime\":\"2017-05-20\",\"color\":\"#103633\",\"image\":\"\",\"file\":\"\",\"location\":\"\"}");
INSERT INTO cmf_plugin VALUES("9","1","1","1","1662171892","AdminJournal","操作日志","https://www.wzxaini9.cn/","","Powerless","https://www.wzxaini9.cn/","1.2.0","后台操作日志","[]");
INSERT INTO cmf_plugin VALUES("10","1","0","1","1670382358","FengiyLogin","微巨宝自定义登录页","","","Fengiy","","1.0","支持大背景/轮播图/Logo/名称自定义","{\"b_bg\":\"\",\"b_bg_illus\":\"\"}");
INSERT INTO cmf_plugin VALUES("11","1","1","1","1718330446","LoginTime","登陆状态时长控制","http://www.songzhenjiang.cn","","Tangchao","http://www.songzhenjiang.cn","1.0","登陆状态时长控制","[]");
INSERT INTO cmf_plugin VALUES("14","1","0","1","1730860671","AliSms","阿里云通信手机验证码","","","五五","","1.2","阿里云通信手机验证码","{\"accessKeyId\":\"LTAI4GAsoanEwxgLjxji6sST\",\"accessKeySecret\":\"epfvZwYVs5LBD8Z9BvU7siVxlGZUVR\",\"SignName\":\"\\u5c0f\\u7a0b\\u5e8f\\u63d0\\u9192\",\"TemplateCode\":\"SMS_469070419\",\"codeKey\":\"code\",\"expire_minute\":\"30\"}");



DROP TABLE cmf_problem;

CREATE TABLE `cmf_problem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `content` text COMMENT '内容',
  `list_order` int(11) DEFAULT '1000',
  `create_time` bigint(20) DEFAULT '0' COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='常见问题';

INSERT INTO cmf_problem VALUES("1","怎么下单预约","&lt;p&gt;答：您可以直接下单，或者是选择技师下单&lt;/p&gt;","1000","1725175155","1725585126","0");
INSERT INTO cmf_problem VALUES("2","测试","&lt;p&gt;测试&lt;/p&gt;","1000","1725175160","1725175164","1725175164");



DROP TABLE cmf_recycle_bin;

CREATE TABLE `cmf_recycle_bin` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` int(11) DEFAULT '0' COMMENT '删除内容 id',
  `create_time` int(10) unsigned DEFAULT '0' COMMENT '创建时间',
  `table_name` varchar(60) DEFAULT '' COMMENT '删除内容所在表名',
  `name` varchar(255) DEFAULT '' COMMENT '删除内容名称',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT=' 回收站';




DROP TABLE cmf_road_price;

CREATE TABLE `cmf_road_price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '备注',
  `begin_time` varchar(255) DEFAULT NULL COMMENT '开始时间',
  `end_time` varchar(255) DEFAULT NULL COMMENT '结束时间',
  `min_km` decimal(10,2) DEFAULT NULL COMMENT '最小距离',
  `max_km` decimal(10,2) DEFAULT NULL COMMENT '最大距离',
  `price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `introduce` varchar(255) DEFAULT NULL COMMENT '介绍',
  `list_order` int(11) DEFAULT '1000',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='路费配置';

INSERT INTO cmf_road_price VALUES("1","0-1km免费","00:00","23:59","0.00","1.00","0.00","单程1公里免费，单程起步价0元1公里","1000","1725004286","1726296278","0");
INSERT INTO cmf_road_price VALUES("2","1-5km 20元","08:00","18:30","1.00","5.00","20.00","单程14.39公里，单程起步价8元2公里，单程超出2 公里后每公里3元，全程往返车费共计90.34元","1000","1725004456","1728801418","0");
INSERT INTO cmf_road_price VALUES("3","5-10km 40元","08:00","18:30","5.00","10.00","40.00","单程14.39公里，单程起步价8元2公里，单程超出2 公里后每公里3元，全程往返车费共计90.34元","1000","1725357656","1728829986","0");



DROP TABLE cmf_role;

CREATE TABLE `cmf_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父角色ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态;0:禁用;1:正常',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `list_order` float NOT NULL DEFAULT '0' COMMENT '排序',
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '角色名称',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `parent_id` (`parent_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='角色表';

INSERT INTO cmf_role VALUES("1","0","1","1329633709","1329633709","0","超级管理员","拥有网站最高管理员权限！");
INSERT INTO cmf_role VALUES("2","0","1","1329633709","1329633709","0","普通管理员","权限由最高管理员分配！");



DROP TABLE cmf_role_user;

CREATE TABLE `cmf_role_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '角色 id',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `role_id` (`role_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户角色对应表';




DROP TABLE cmf_route;

CREATE TABLE `cmf_route` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '路由id',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态;1:启用,0:不启用',
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'URL规则类型;1:用户自定义;2:别名添加',
  `full_url` varchar(255) NOT NULL DEFAULT '' COMMENT '完整url',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '实际显示的url',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='url路由表';




DROP TABLE cmf_shop;

CREATE TABLE `cmf_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '关联用户',
  `class_id` int(11) DEFAULT NULL COMMENT '分类id',
  `shop_type` tinyint(4) DEFAULT NULL COMMENT '类型:1全屋整装,2装修建材,3智能电器,5家具软装 ',
  `name` varchar(50) DEFAULT NULL COMMENT '店铺名字',
  `logo_image` varchar(200) DEFAULT NULL COMMENT 'logo',
  `images` text COMMENT '轮播图',
  `introduce` varchar(255) DEFAULT NULL COMMENT '介绍',
  `phone` varchar(15) DEFAULT NULL COMMENT '手机号',
  `time` varchar(80) DEFAULT NULL COMMENT '营业时间',
  `address` varchar(300) DEFAULT NULL COMMENT '地址信息',
  `lng` varchar(30) DEFAULT NULL COMMENT '经度',
  `lat` varchar(30) DEFAULT NULL COMMENT '纬度',
  `lnglat` varchar(50) DEFAULT NULL COMMENT '经纬度',
  `province_id` varchar(50) DEFAULT NULL COMMENT '省id',
  `city_id` varchar(50) DEFAULT NULL COMMENT '市id',
  `county_id` varchar(50) DEFAULT NULL COMMENT '区id',
  `province` varchar(50) DEFAULT NULL COMMENT '省name',
  `city` varchar(50) DEFAULT NULL COMMENT '市name',
  `county` varchar(50) DEFAULT NULL COMMENT '区name',
  `province_code` varchar(50) DEFAULT NULL COMMENT '省code',
  `city_code` varchar(50) DEFAULT NULL COMMENT '市code',
  `county_code` varchar(50) DEFAULT NULL COMMENT '区code',
  `list_order` int(11) DEFAULT '0' COMMENT '人气',
  `is_recommend` tinyint(2) DEFAULT '1' COMMENT '推荐:1是,2否',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='店铺管理';




DROP TABLE cmf_shop_address;

CREATE TABLE `cmf_shop_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `province_id` varchar(50) DEFAULT NULL COMMENT '省id',
  `city_id` varchar(50) DEFAULT NULL COMMENT '市id',
  `county_id` varchar(50) DEFAULT NULL COMMENT '区id',
  `province` varchar(50) DEFAULT NULL COMMENT '省name',
  `city` varchar(50) DEFAULT NULL COMMENT '市name',
  `county` varchar(50) DEFAULT NULL COMMENT '区name',
  `province_code` varchar(255) DEFAULT NULL COMMENT '省code',
  `city_code` varchar(255) DEFAULT NULL COMMENT '市code',
  `county_code` varchar(255) DEFAULT NULL COMMENT '区code',
  `address` varchar(120) DEFAULT NULL COMMENT '详细地址',
  `username` varchar(30) DEFAULT NULL COMMENT '名字',
  `phone` varchar(20) DEFAULT NULL COMMENT '电话',
  `is_default` tinyint(2) DEFAULT '2' COMMENT '是否默认:1默认,2不默认',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态:1正常',
  `lng` varchar(30) DEFAULT NULL COMMENT '经度',
  `lat` varchar(30) DEFAULT NULL COMMENT '纬度',
  `lnglat` varchar(50) DEFAULT NULL COMMENT '经纬度',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='地址管理';




DROP TABLE cmf_shop_cart;

CREATE TABLE `cmf_shop_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '关联用户',
  `goods_id` int(11) DEFAULT NULL COMMENT '商品id',
  `count` int(11) DEFAULT NULL COMMENT '下单数量',
  `sku_id` int(11) DEFAULT NULL COMMENT '规格id',
  `sku_name` varchar(255) DEFAULT NULL COMMENT 'sku_name',
  `create_time` bigint(20) DEFAULT NULL COMMENT '下单时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='购物车';




DROP TABLE cmf_shop_comment;

CREATE TABLE `cmf_shop_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '关联用户',
  `goods_id` int(11) DEFAULT NULL COMMENT '商品',
  `order_detail_id` int(11) DEFAULT NULL COMMENT '订单详情',
  `content` text COMMENT '评论内容',
  `images` text COMMENT '图片',
  `is_show` tinyint(2) DEFAULT '1' COMMENT '是否显示:1显示,2隐藏',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='评价';




DROP TABLE cmf_shop_coupon;

CREATE TABLE `cmf_shop_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) DEFAULT '1' COMMENT '优惠券类型:1通用,2餐饮',
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '优惠券名称',
  `full_amount` float DEFAULT NULL COMMENT '满额',
  `amount` float DEFAULT NULL COMMENT '面额',
  `count` int(11) DEFAULT NULL COMMENT '数量',
  `select_count` int(11) DEFAULT '0' COMMENT '领取数量',
  `limit` int(11) DEFAULT '1' COMMENT '限领取数',
  `status` tinyint(4) DEFAULT '2' COMMENT '状态:1显示,2隐藏',
  `start_time` int(11) DEFAULT NULL COMMENT '开始时间',
  `end_time` int(11) DEFAULT NULL COMMENT '结束时间',
  `content` text COMMENT '内容',
  `indate` int(11) DEFAULT '7' COMMENT '有效期',
  `list_order` int(11) DEFAULT '1000',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='优惠券';

INSERT INTO cmf_shop_coupon VALUES("1","1","满20立减5元","20","5","0","0","1","2","0","2024","","7","1000","1725007083","1725007113","1725007113");
INSERT INTO cmf_shop_coupon VALUES("2","1","满200立减10元","200","10","0","0","1","2","0","1727452799","","7","1000","1725007163","1728905986","1728905986");
INSERT INTO cmf_shop_coupon VALUES("3","1","测试","100","10","","0","1","1","","1730390399","","7","1000","1728959150","1728959177","1728959177");
INSERT INTO cmf_shop_coupon VALUES("4","1","满200元立减20元","200","20","","0","1","1","","1735574399","","7","1000","1728988526","1733904786","0");



DROP TABLE cmf_shop_coupon_user;

CREATE TABLE `cmf_shop_coupon_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `coupon_id` int(11) NOT NULL COMMENT '优惠券id',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态:1正常',
  `used` tinyint(4) DEFAULT '1' COMMENT '状态:1未使用,2已使用,3已过期',
  `name` varchar(32) DEFAULT NULL COMMENT '优惠券名称',
  `full_amount` float DEFAULT '0' COMMENT '满n金额',
  `amount` float DEFAULT '0' COMMENT '金额',
  `start_time` bigint(20) DEFAULT NULL COMMENT '开始时间',
  `end_time` bigint(20) DEFAULT NULL COMMENT '结束时间',
  `code` varchar(32) DEFAULT NULL COMMENT 'code码',
  `qr_image` varchar(100) DEFAULT NULL COMMENT '二维码',
  `order_num` varchar(32) DEFAULT NULL COMMENT '关联订单号',
  `is_send` tinyint(4) DEFAULT '1' COMMENT '是否发放:1赠送的',
  `type` tinyint(4) DEFAULT NULL COMMENT '类型:',
  `used_time` bigint(20) DEFAULT '0' COMMENT '使用时间',
  `create_time` bigint(20) NOT NULL COMMENT '领取时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `code` (`code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='优惠券领取记录';




DROP TABLE cmf_shop_goods;

CREATE TABLE `cmf_shop_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) DEFAULT '1' COMMENT '商品类型:1抢购,2限购',
  `shop_id` int(11) DEFAULT NULL COMMENT '门店id',
  `class_id` int(11) DEFAULT NULL COMMENT '分类',
  `goods_name` varchar(60) DEFAULT NULL COMMENT '商品名称',
  `price` decimal(8,2) DEFAULT '0.00' COMMENT '价格',
  `old_price` decimal(10,2) DEFAULT NULL COMMENT '原价',
  `minute` varchar(255) DEFAULT NULL COMMENT '分钟',
  `image` varchar(255) DEFAULT NULL COMMENT '封面',
  `images` text COMMENT '图集',
  `introduce` varchar(255) DEFAULT NULL COMMENT '介绍',
  `content` text COMMENT '详情',
  `status` tinyint(2) DEFAULT '1' COMMENT '是否展示:1展示,2隐藏',
  `sell_count` int(11) DEFAULT '0' COMMENT '预约人数',
  `is_index` tinyint(2) DEFAULT '2' COMMENT '首页推荐:1是,2否',
  `list_order` int(11) DEFAULT '1000',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `dindex` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COMMENT='商品管理';

INSERT INTO cmf_shop_goods VALUES("1","0","0","2","古法采耳","188.00","288.00","60","dzkf346/admin/20241013/11a545f02e83805496c211098eb7d99d.jpg","","古法采耳","&lt;p&gt;&lt;img src=&quot;https://oss.ausite.cn/dzkf346/default/20241012/82e4b12f5bb95a6847fa72e94761650f.jpg?watermark&quot; title=&quot;古法采耳.jpg&quot; alt=&quot;古法采耳.jpg&quot;/&gt;&lt;/p&gt;","1","100","1","1000","1724986512","1730096067","1730096067");
INSERT INTO cmf_shop_goods VALUES("2","0","0","7","瑜伽SPA","498.00","588.00","100","dzkf346/admin/20241014/866385939cc62570f9d4530070496e38.jpg","","瑜伽SPA","&lt;p&gt;&lt;img src=&quot;https://oss.ausite.cn/dzkf346/default/20241012/b71fc09243006003da4fe467285ffbd5.jpg?watermark&quot; title=&quot;瑜伽SPA.jpg&quot; alt=&quot;瑜伽SPA.jpg&quot;/&gt;&lt;/p&gt;","1","100","1","1000","1725009276","1730164658","0");
INSERT INTO cmf_shop_goods VALUES("3","0","0","7","香薰SPA","398.00","498.00","90","dzkf346/admin/20241014/e8916d701bd4aa9ab741484fefb268b3.jpg","","","&lt;p&gt;&lt;img src=&quot;https://oss.ausite.cn/dzkf346/default/20241012/8657748e947ae43ee2c86d72b510cb3d.jpg?watermark&quot; title=&quot;香薰SPA.jpg&quot; alt=&quot;香薰SPA.jpg&quot;/&gt;&lt;/p&gt;","1","100","1","1000","1725009302","1730164650","0");
INSERT INTO cmf_shop_goods VALUES("4","0","0","7","意境SPA","298.00","388.00","80","dzkf346/admin/20241013/5d18cd7d83c278d3898611bb693dbf9f.jpg","","油压SPA","&lt;p&gt;&lt;img src=&quot;https://oss.ausite.cn/dzkf346/default/20241012/9a6fb188eb309b644b41cd9de0fd8eae.jpg?watermark&quot; title=&quot;意境SPA.jpg&quot; alt=&quot;意境SPA.jpg&quot;/&gt;&lt;/p&gt;","1","100","1","1000","1725583856","1730164644","0");
INSERT INTO cmf_shop_goods VALUES("5","0","0","8","养生足道","218.00","259.00","60","dzkf346/admin/20241013/5004652b94a2465e40d3e5319fd1bfef.jpg","","足底按摩60分钟","&lt;p&gt;&lt;img src=&quot;https://oss.ausite.cn/dzkf346/default/20241012/439a83447b69731166a5764c8a72dda8.jpg?watermark&quot; title=&quot;养生足道.jpg&quot; alt=&quot;养生足道.jpg&quot;/&gt;&lt;/p&gt;","1","100","1","1000","1725602044","1730164638","0");
INSERT INTO cmf_shop_goods VALUES("6","0","0","7","至尊轻柔SPA","698.00","898.00","120","dzkf346/admin/20241013/5e8def22a41a4648a2843b0728381608.jpg","","","&lt;p&gt;&lt;img src=&quot;https://oss.ausite.cn/dzkf346/default/20241012/8645499a0f6a52e72fc1f8ef7c443749.jpg?watermark&quot; title=&quot;至尊轻柔SPA.jpg&quot; alt=&quot;至尊轻柔SPA.jpg&quot;/&gt;&lt;/p&gt;","1","100","1","1000","1728398615","1730164632","0");
INSERT INTO cmf_shop_goods VALUES("7","0","0","6","舒缓按摩","258.00","299.00","70","dzkf346/admin/20241013/99653b0041d3541e688bcb5173da14bc.jpg","","","&lt;p&gt;&lt;img src=&quot;https://oss.ausite.cn/dzkf346/default/20241012/a0ff92bf6eef728365a4f69e869f682b.jpg?watermark&quot; title=&quot;舒缓按摩.jpg&quot; alt=&quot;舒缓按摩.jpg&quot;/&gt;&lt;/p&gt;","1","100","1","1000","1728398905","1730164625","0");



DROP TABLE cmf_shop_goods_class;

CREATE TABLE `cmf_shop_goods_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `image` varchar(255) DEFAULT NULL COMMENT '图标',
  `taboo_instructions` text COMMENT '禁忌说明',
  `order_notice` text COMMENT '下单须知',
  `list_order` int(11) DEFAULT '1000',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `dindex` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COMMENT='分类管理';

INSERT INTO cmf_shop_goods_class VALUES("1","油压SPA","dzkf346/admin/20240906/20c40c231226a34e936ba7499c80124d.png","","","100","1724986215","1725779873","1725779873");
INSERT INTO cmf_shop_goods_class VALUES("2","推拿调理","dzkf346/admin/20240906/7989e879d92efad89184fff8a8dfddd8.png","","","200","1724986228","1725779878","1725779878");
INSERT INTO cmf_shop_goods_class VALUES("3","采耳针灸","dzkf346/admin/20240906/7918000d297b0fe398b70fc2b173a988.png","","","1000","1725583555","1725779888","1725779888");
INSERT INTO cmf_shop_goods_class VALUES("4","经典理疗","dzkf346/admin/20240906/8973aa936b015a5029e318e7556a7dc7.png","","","1000","1725583591","1725779885","1725779885");
INSERT INTO cmf_shop_goods_class VALUES("5","泰式按摩","dzkf346/admin/20240906/0e2a60bea066661341d740590a8edd2b.png","","","1000","1725583694","1725779881","1725779881");
INSERT INTO cmf_shop_goods_class VALUES("6","推拿按摩","","","","1000","1730164583","","0");
INSERT INTO cmf_shop_goods_class VALUES("7","休闲SPA","","","","1000","1730164595","","0");
INSERT INTO cmf_shop_goods_class VALUES("8","养生足道","","","","1000","1730164612","","0");



DROP TABLE cmf_shop_goods_sku;

CREATE TABLE `cmf_shop_goods_sku` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_id` int(11) DEFAULT NULL COMMENT '店铺',
  `goods_id` int(11) DEFAULT NULL COMMENT '商品id',
  `goods_name` varchar(255) DEFAULT NULL,
  `sku_name` varchar(30) DEFAULT NULL COMMENT 'sku',
  `stock` int(11) DEFAULT '0' COMMENT '库存',
  `price` decimal(8,2) DEFAULT '0.00' COMMENT '价格',
  `line_price` decimal(10,2) DEFAULT NULL COMMENT '原价',
  `status` tinyint(4) DEFAULT '1' COMMENT '0不显示 1正常',
  `image` varchar(255) DEFAULT NULL COMMENT '图片',
  `code` varchar(255) DEFAULT NULL COMMENT '编码',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品sku';




DROP TABLE cmf_shop_order;

CREATE TABLE `cmf_shop_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) DEFAULT '1' COMMENT '订单类型:1正常下单,2加钟',
  `shop_id` int(11) DEFAULT NULL COMMENT '门店id',
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `technician_id` int(11) DEFAULT NULL COMMENT '技师id',
  `status` tinyint(8) DEFAULT '1' COMMENT '状态:1待付款,2待接单,3待服务,4进行中,5待评价,8已完成,9用户取消,10系统已取消,11技师已取消,12退款申请,14退款不通过,16退款通过  6已出发  7已到达',
  `order_num` varchar(255) DEFAULT NULL COMMENT '订单号',
  `p_order_num` varchar(255) DEFAULT NULL COMMENT '父单号',
  `pay_num` varchar(255) DEFAULT NULL,
  `address_id` int(11) DEFAULT '0' COMMENT '地址id',
  `openid` varchar(255) DEFAULT NULL COMMENT '身份标识 openid',
  `username` varchar(255) DEFAULT NULL COMMENT '姓名',
  `phone` varchar(255) DEFAULT NULL COMMENT '手机号',
  `province` varchar(255) DEFAULT NULL COMMENT '省',
  `city` varchar(255) DEFAULT NULL COMMENT '市',
  `county` varchar(255) DEFAULT NULL COMMENT '区',
  `province_code` varchar(255) DEFAULT NULL COMMENT '省code',
  `city_code` varchar(255) DEFAULT NULL COMMENT '市code',
  `county_code` varchar(255) DEFAULT NULL COMMENT '区code',
  `lng` varchar(255) DEFAULT NULL COMMENT '经度',
  `lat` varchar(255) DEFAULT NULL COMMENT '纬度',
  `lnglat` varchar(255) DEFAULT NULL COMMENT '经纬度',
  `address` varchar(255) DEFAULT NULL COMMENT '详细地址',
  `km` varchar(255) DEFAULT NULL COMMENT '距离',
  `amount` decimal(8,2) DEFAULT NULL COMMENT '实际支付金额',
  `balance` decimal(10,2) DEFAULT NULL COMMENT '余额支付金额',
  `goods_amount` decimal(8,2) DEFAULT NULL COMMENT '商品金额',
  `refund_amount` decimal(10,2) DEFAULT NULL COMMENT '退款金额',
  `compensate_amount` decimal(10,2) DEFAULT NULL COMMENT '补偿技师金额',
  `total_amount` decimal(8,2) DEFAULT NULL COMMENT '原始 总金额 = 商品金额+优惠金额+运费金额',
  `total_minute` varchar(255) DEFAULT NULL COMMENT '总分钟数',
  `coupon_id` int(11) DEFAULT '0' COMMENT '优惠券id',
  `coupon_amount` decimal(8,2) DEFAULT '0.00' COMMENT '优惠金额',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '打车费',
  `total_commission` decimal(10,2) DEFAULT NULL COMMENT '总佣金',
  `travel_type` varchar(255) DEFAULT NULL COMMENT '出行方式',
  `pay_type` tinyint(4) DEFAULT '1' COMMENT '支付类型:1微信支付,2余额支付,3积分支付,4支付宝支付,5组合支付(微信+余额)',
  `remark` varchar(300) DEFAULT '' COMMENT '备注',
  `cav_qr_code` varchar(200) DEFAULT NULL COMMENT '核销二维码',
  `cav_code` varchar(40) DEFAULT NULL COMMENT '核销码',
  `exp_num` varchar(60) DEFAULT NULL COMMENT '快递名称',
  `exp_name` varchar(60) DEFAULT NULL COMMENT '快递名称',
  `begin_time` bigint(20) DEFAULT NULL COMMENT '开始时间',
  `end_time` bigint(20) DEFAULT NULL COMMENT '结束时间',
  `depart_time` bigint(20) DEFAULT NULL COMMENT '出发时间',
  `reach_time` bigint(20) DEFAULT NULL COMMENT '到达时间',
  `cancel_time` bigint(20) DEFAULT NULL COMMENT '取消时间',
  `receive_time` bigint(20) DEFAULT NULL COMMENT '接单时间',
  `start_time` bigint(20) DEFAULT NULL COMMENT '开始服务时间',
  `accomplish_time` bigint(20) DEFAULT NULL COMMENT '完成时间',
  `evaluate_time` bigint(20) DEFAULT NULL COMMENT '评价时间',
  `done_time` bigint(20) DEFAULT NULL COMMENT '结束时间',
  `residue_time` bigint(20) DEFAULT '0' COMMENT '剩余时间',
  `pay_time` bigint(20) DEFAULT '0' COMMENT '支付时间',
  `send_time` bigint(20) DEFAULT NULL COMMENT '发货时间',
  `refund_time` bigint(20) DEFAULT NULL COMMENT '退款时间',
  `take_delivery_time` bigint(20) DEFAULT NULL COMMENT '收货时间',
  `auto_cancel_time` bigint(20) DEFAULT NULL COMMENT '自动取消时间',
  `auto_technician_cancel_time` bigint(20) DEFAULT NULL COMMENT '技师自动取消时间',
  `auto_accomplish_time` bigint(20) DEFAULT NULL COMMENT '自动完成时间',
  `auto_verification_time` bigint(20) DEFAULT NULL COMMENT '自动核销时间',
  `auto_receive_time` bigint(20) DEFAULT NULL COMMENT '自动接单时间',
  `catr_ids` varchar(255) DEFAULT NULL COMMENT '购物车下单',
  `goods_name` varchar(2555) DEFAULT NULL COMMENT '商品名字',
  `goods_ids` varchar(255) DEFAULT NULL COMMENT '商品ids',
  `admin_remark` varchar(255) DEFAULT NULL COMMENT '管理员备注',
  `create_time` bigint(20) DEFAULT NULL COMMENT '下单时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  `cancel_identity_type` varchar(255) DEFAULT NULL COMMENT '取消订单身份类型',
  `cancel_content` varchar(255) DEFAULT NULL COMMENT '取消理由',
  `cancel_images` text COMMENT '取消图片',
  `cancel_status` tinyint(4) DEFAULT '2' COMMENT '技师取消状态:1审核中,2已通过,3已拒绝',
  `cancel_refuse` varchar(255) DEFAULT NULL COMMENT '拒绝理由',
  `pass_time` bigint(20) DEFAULT NULL COMMENT '通过时间',
  `refuse_time` bigint(20) DEFAULT NULL COMMENT '拒绝时间',
  `refund_pass_time` bigint(20) DEFAULT NULL COMMENT '技师n分钟不接单       自动取消时间',
  `complaint_time` bigint(20) DEFAULT NULL COMMENT '投诉时间',
  `is_complaint` tinyint(4) DEFAULT '2' COMMENT '投诉:1已投诉,2未投诉',
  `pid` int(11) DEFAULT NULL COMMENT '分销员',
  `effective_invitation` tinyint(4) DEFAULT '2' COMMENT '是否有效邀请:1是,2否',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `dindex` (`user_id`,`order_num`(191),`technician_id`,`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='订单管理';




DROP TABLE cmf_shop_order_address;

CREATE TABLE `cmf_shop_order_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operate` varchar(255) DEFAULT NULL COMMENT '操作说明:receive=接单,depart=已出发,reach=已到达,start=开始服务,done=结束服务,cancel=取消订单,alarm=报警',
  `technician_id` int(11) DEFAULT NULL COMMENT '技师id',
  `phone` varchar(255) DEFAULT NULL COMMENT '技师手机号',
  `nickname` varchar(255) DEFAULT NULL COMMENT '技师姓名',
  `order_num` varchar(255) DEFAULT NULL COMMENT '订单号',
  `lng` varchar(255) DEFAULT NULL COMMENT '经度',
  `lat` varchar(255) DEFAULT NULL COMMENT '纬度',
  `lnglat` varchar(255) DEFAULT NULL COMMENT '经纬度',
  `address` varchar(255) DEFAULT NULL COMMENT '详细地址',
  `create_time` bigint(20) DEFAULT NULL COMMENT '下单时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `dindex` (`order_num`(191)) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='技师定位';




DROP TABLE cmf_shop_order_complaint;

CREATE TABLE `cmf_shop_order_complaint` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户',
  `order_num` varchar(255) DEFAULT NULL COMMENT '订单号',
  `images` text COMMENT '图片',
  `content` varchar(255) DEFAULT NULL COMMENT '内容',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单投诉';




DROP TABLE cmf_shop_order_detail;

CREATE TABLE `cmf_shop_order_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_id` int(11) DEFAULT NULL COMMENT '店铺',
  `user_id` int(11) DEFAULT NULL COMMENT '用户',
  `goods_id` int(11) DEFAULT NULL COMMENT '商品',
  `sku_id` int(11) DEFAULT NULL COMMENT '规格',
  `goods_name` varchar(255) DEFAULT NULL COMMENT '商品名字',
  `sku_name` varchar(255) DEFAULT NULL COMMENT '规格名字',
  `count` int(11) DEFAULT NULL COMMENT '购买数量',
  `is_vip` tinyint(4) DEFAULT '0' COMMENT '是否是会员:0否,1是',
  `minute` varchar(255) DEFAULT NULL COMMENT '分钟',
  `total_minute` varchar(255) DEFAULT NULL COMMENT '总分钟',
  `goods_price` decimal(8,2) DEFAULT NULL COMMENT '价格/单价',
  `old_price` decimal(10,2) DEFAULT NULL COMMENT '划线价',
  `vip_price` decimal(8,2) DEFAULT '0.00' COMMENT '会员价/单价   同步到普通单价里面,方便展示',
  `vip_amount` decimal(8,2) DEFAULT '0.00' COMMENT '会员价/合计   同步到普通合计里面,方便展示',
  `coupon_amount` decimal(8,2) DEFAULT '0.00' COMMENT '优惠金额',
  `total_amount` decimal(8,2) DEFAULT NULL COMMENT '合计',
  `introduce` varchar(255) DEFAULT NULL COMMENT '介绍',
  `sell_count` varchar(255) DEFAULT NULL COMMENT '人数',
  `image` varchar(255) DEFAULT NULL COMMENT '展示图',
  `status` tinyint(4) DEFAULT NULL COMMENT '退款状态:0未提交,1审核中,2已通过,3已驳回',
  `order_num` varchar(255) DEFAULT '0' COMMENT '订单单号',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `order_num` (`order_num`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单详情';




DROP TABLE cmf_shop_order_evaluate;

CREATE TABLE `cmf_shop_order_evaluate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户',
  `technician_id` int(11) DEFAULT NULL COMMENT '技师管理',
  `order_num` varchar(255) DEFAULT NULL COMMENT '订单号',
  `star` varchar(255) DEFAULT '5' COMMENT '星级',
  `evaluate` varchar(255) DEFAULT NULL COMMENT '评价',
  `create_time` bigint(20) DEFAULT NULL COMMENT '下单时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `user_id` (`user_id`,`technician_id`,`order_num`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='评价管理';




DROP TABLE cmf_shop_order_refund;

CREATE TABLE `cmf_shop_order_refund` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) DEFAULT '1' COMMENT '订单类型:1抢购,2限购',
  `user_id` int(11) DEFAULT NULL COMMENT '用户',
  `refund_why` varchar(300) DEFAULT NULL COMMENT '退款原因',
  `order_num` varchar(120) DEFAULT NULL COMMENT '退款订单号',
  `amount` decimal(8,2) DEFAULT NULL COMMENT '退款金额',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态:1审核中, 2已通过,3已驳回,4已取消',
  `refuse` varchar(255) DEFAULT NULL COMMENT '拒绝理由',
  `refund_num` varchar(255) DEFAULT NULL COMMENT '退款订单号',
  `content` text COMMENT '说明',
  `images` text COMMENT '图集',
  `refuse_time` bigint(20) DEFAULT NULL COMMENT '拒绝时间',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='退款管理';




DROP TABLE cmf_shop_order_save;

CREATE TABLE `cmf_shop_order_save` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `technician_id` int(11) DEFAULT NULL COMMENT '技师',
  `user_id` int(11) DEFAULT NULL COMMENT '用户',
  `status` tinyint(4) DEFAULT '0' COMMENT '状态:0未提交,1已支付,2已取消,3已完成',
  `order_num` varchar(255) DEFAULT '0' COMMENT '订单单号',
  `begin_time` bigint(20) DEFAULT NULL COMMENT '开始时间戳',
  `end_time` bigint(20) DEFAULT NULL COMMENT '结束时间戳',
  `operation_end_time` bigint(20) DEFAULT NULL COMMENT '结束',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `technician_id` (`technician_id`,`user_id`,`status`,`order_num`,`begin_time`,`end_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COMMENT='技师已约时间';

INSERT INTO cmf_shop_order_save VALUES("119","1","1","1","241206774466171599","1733588400","1733602800","","1733477446","1733477446","0");



DROP TABLE cmf_slide;

CREATE TABLE `cmf_slide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:显示,0不显示',
  `delete_time` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
  `name` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '幻灯片分类',
  `remark` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '分类备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='幻灯片表';

INSERT INTO cmf_slide VALUES("1","1","0","首页轮播图","首页轮播图[请勿删除]");



DROP TABLE cmf_slide_item;

CREATE TABLE `cmf_slide_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slide_id` int(11) NOT NULL DEFAULT '0' COMMENT '幻灯片id',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:显示;0:隐藏',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '幻灯片名称',
  `image` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '幻灯片图片',
  `url` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '幻灯片链接',
  `target` varchar(10) NOT NULL DEFAULT '' COMMENT '友情链接打开方式',
  `description` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '幻灯片描述',
  `content` text CHARACTER SET utf8 COMMENT '幻灯片内容',
  `more` text COMMENT '扩展信息',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `slide_id` (`slide_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='幻灯片子项表';

INSERT INTO cmf_slide_item VALUES("1","1","1","1000","1","dz000/admin/20220928/f6eb31a4707d3e8705bce2402f331592.jpg","/pages/user/index","navigateTo","9999","","");



DROP TABLE cmf_technician;

CREATE TABLE `cmf_technician` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '关联用户',
  `openid` varchar(255) DEFAULT NULL,
  `wx_openid` varchar(255) DEFAULT NULL,
  `avatar` text COMMENT '头像',
  `nickname` varchar(255) DEFAULT NULL COMMENT '昵称',
  `gender` varchar(255) DEFAULT NULL COMMENT '性别',
  `phone` varchar(255) DEFAULT NULL COMMENT '联系电话',
  `pass` varchar(255) DEFAULT NULL COMMENT '密码',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态:1审核中,2已通过,3已拒绝',
  `sell_count` int(11) DEFAULT '0' COMMENT '服务单数',
  `virtually_sell_count` int(11) DEFAULT '0' COMMENT '虚拟单数',
  `virtually_like_count` int(255) DEFAULT '0' COMMENT '虚拟收藏数',
  `sign_image` text COMMENT '签名',
  `balance` decimal(10,2) DEFAULT '0.00',
  `invite_code` varchar(255) DEFAULT NULL COMMENT '邀请码',
  `pid` int(11) DEFAULT '0' COMMENT '上级',
  `commission` varchar(255) DEFAULT NULL COMMENT '佣金比例',
  `identity_images` text COMMENT '身份证照片',
  `qualifications_image` varchar(255) DEFAULT NULL COMMENT '资质照片',
  `introduce` varchar(255) DEFAULT NULL COMMENT '介绍',
  `goods_ids` text COMMENT '关联项目',
  `province_id` varchar(50) DEFAULT NULL COMMENT '省id',
  `city_id` varchar(50) DEFAULT NULL COMMENT '市id',
  `county_id` varchar(50) DEFAULT NULL COMMENT '区id',
  `province` varchar(50) DEFAULT NULL COMMENT '省name',
  `city` varchar(50) DEFAULT NULL COMMENT '市name',
  `county` varchar(50) DEFAULT NULL COMMENT '区name',
  `province_code` varchar(255) DEFAULT NULL COMMENT '省code',
  `city_code` varchar(255) DEFAULT NULL COMMENT '市code',
  `county_code` varchar(255) DEFAULT NULL COMMENT '区code',
  `address` varchar(120) DEFAULT NULL COMMENT '详细地址',
  `lng` varchar(30) DEFAULT NULL COMMENT '经度',
  `lat` varchar(30) DEFAULT NULL COMMENT '纬度',
  `lnglat` varchar(50) DEFAULT NULL COMMENT '经纬度',
  `is_new` tinyint(4) DEFAULT '2' COMMENT '新人推荐:1是,2否',
  `is_index` tinyint(4) DEFAULT '2' COMMENT '平台推荐:1是,2否',
  `is_send` tinyint(4) DEFAULT '2' COMMENT '上级返佣:1是,2否',
  `star` varchar(255) DEFAULT '5' COMMENT '星级',
  `work_status` tinyint(4) DEFAULT '1' COMMENT '工作状态:1可服务,2服务中,3已下线',
  `refuse` varchar(255) DEFAULT NULL COMMENT '拒绝理由',
  `pass_time` bigint(20) DEFAULT NULL COMMENT '通过时间',
  `refuse_time` bigint(20) DEFAULT NULL COMMENT '拒绝时间',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  `is_block` tinyint(4) DEFAULT '2' COMMENT '拉黑:1是,2否',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `user_id` (`user_id`,`phone`,`status`,`work_status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='技师管理';

INSERT INTO cmf_technician VALUES("1","1","Technician_620581261b0fac151512432c9e48888","000000","dzam1000/admin/20241230/972ae3258a75c6cd316dfb1a00c86312.jpg,dzam1000/admin/20241230/fc92e9c3a9ee6368599f89eeb6ae956e.jpeg,dzam1000/admin/20241230/4a33eb064f513d45da48fb9a84755989.jpg,dzam1000/admin/20241230/ef65ecab95a1f8479595c2b1eb027268.jpeg","测试人员","男","18582300000","###69bad127654ba4ed702e0acc9e6d5cb7","2","9","0","0","data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+PCFET0NUWVBFIHN2ZyBQVUJMSUMgIi0vL1czQy8vRFREIFNWRyAxLjEvL0VOIiAiaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEuZHRkIj48c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgdmVyc2lvbj0iMS4xIiB3aWR0aD0iNzEyLjk5OTE0NTUwNzgxMjUiIGhlaWdodD0iMzEwLjMyOTg2NDUwMTk1MzEiPjxwYXRoIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIzIiBzdHJva2U9InJnYigwLDAsMCkiIGZpbGw9Im5vbmUiIGQ9Ik0gMTY4LjMgMTQzLjUyOTg2NDUwMTk1MzEgTCAxNjguMyAxNDMuNTI5ODY0NTAxOTUzMSBMIDE3NiAxNTIuNjI5ODY0NTAxOTUzMTQgTCAxODMuNyAxNjAuMTI5ODY0NTAxOTUzMTQgTCAxODcuOSAxNjQuMDI5ODY0NTAxOTUzMSBMIDE5Ni42IDE3Mi4wMjk4NjQ1MDE5NTMxIEwgMjAxLjMgMTc2LjAyOTg2NDUwMTk1MzEgTCAyMTYuNiAxODguMjI5ODY0NTAxOTUzMSBMIDIyNy4zIDE5NS41Mjk4NjQ1MDE5NTMxIEwgMjM3LjkgMjAyLjIyOTg2NDUwMTk1MzEgTCAyNDcuNCAyMDcuMzI5ODY0NTAxOTUzMTIgTCAyNTUuOSAyMTEuMzI5ODY0NTAxOTUzMTIgTCAyNjIuOSAyMTMuMTI5ODY0NTAxOTUzMTQgTCAyNjcuOCAyMTMuNDI5ODY0NTAxOTUzMSBMIDI3MC44IDIxMi4yMjk4NjQ1MDE5NTMxIEwgMjczLjIgMjA4LjgyOTg2NDUwMTk1MzEyIEwgMjc0LjEgMjAzLjgyOTg2NDUwMTk1MzEyIEwgMjc0LjIgMTk2LjMyOTg2NDUwMTk1MzEyIEwgMjcyLjkgMTg3LjcyOTg2NDUwMTk1MzEgTCAyNzEuMiAxNzguMTI5ODY0NTAxOTUzMTQgTCAyNjkuNyAxNjguMTI5ODY0NTAxOTUzMTQgTCAyNjcuOSAxNTguODI5ODY0NTAxOTUzMTIgTCAyNjYuNyAxNDkuNzI5ODY0NTAxOTUzMSBMIDI2Ni4zIDE0Mi4zMjk4NjQ1MDE5NTMxMiBMIDI2Ni40IDEzNi43Mjk4NjQ1MDE5NTMxIEwgMjY3LjUgMTMzLjMyOTg2NDUwMTk1MzEyIEwgMjY5LjggMTMxLjIyOTg2NDUwMTk1MzEgTCAyNzMuOSAxMzAuNzI5ODY0NTAxOTUzMSBMIDI4MS40IDEzMi45Mjk4NjQ1MDE5NTMxIEwgMjkxLjIgMTM3LjkyOTg2NDUwMTk1MzEgTCAzMDIuMiAxNDQuOTI5ODY0NTAxOTUzMSBMIDMxMy42IDE1My4yMjk4NjQ1MDE5NTMxIEwgMzI1LjcgMTYyLjIyOTg2NDUwMTk1MzEgTCAzMzcuNyAxNzAuNzI5ODY0NTAxOTUzMSBMIDM0OC45IDE3OS4zMjk4NjQ1MDE5NTMxMiBMIDM1OS42IDE4Ny4wMjk4NjQ1MDE5NTMxIEwgMzY4LjMgMTkzLjMyOTg2NDUwMTk1MzEyIEwgMzc1LjIgMTk4LjEyOTg2NDUwMTk1MzE0IEwgMzc5LjkgMjAwLjUyOTg2NDUwMTk1MzEgTCAzODIuNSAyMDEuNTI5ODY0NTAxOTUzMSBMIDM4My45IDIwMS41Mjk4NjQ1MDE5NTMxIEwgMzg1LjMgMjAwLjEyOTg2NDUwMTk1MzE0IEwgMzg2LjcgMTk3LjEyOTg2NDUwMTk1MzE0IEwgMzg3LjcgMTkyLjAyOTg2NDUwMTk1MzEgTCAzODcuOSAxODUuMDI5ODY0NTAxOTUzMSBMIDM4Ny45IDE3NS45Mjk4NjQ1MDE5NTMxNSBMIDM4Ny44IDE2Ni41Mjk4NjQ1MDE5NTMxIEwgMzg3LjcgMTU2LjkyOTg2NDUwMTk1MzE1IEwgMzg4IDE0OC4yMjk4NjQ1MDE5NTMxNiBMIDM4OC43IDE0MS4xMjk4NjQ1MDE5NTMxNCBMIDM4OS45IDEzNi4zMjk4NjQ1MDE5NTMxMiBMIDM5MS4yIDEzMy42Mjk4NjQ1MDE5NTMxNCBMIDM5Mi42IDEzMi40Mjk4NjQ1MDE5NTMxNSBMIDM5NSAxMzIuNDI5ODY0NTAxOTUzMTUgTCAzOTkuOCAxMzQuNjI5ODY0NTAxOTUzMTQgTCA0MDcuMSAxNDAuMTI5ODY0NTAxOTUzMTQgTCA0MTUuOSAxNDcuMTI5ODY0NTAxOTUzMTQgTCA0MjQuOCAxNTUuMzI5ODY0NTAxOTUzMTIgTCA0MzQuMiAxNjMuODI5ODY0NTAxOTUzMTIgTCA0NDQuNiAxNzIuMTI5ODY0NTAxOTUzMTQgTCA0NTMuOSAxODAuMDI5ODY0NTAxOTUzMSBMIDQ2My4xIDE4Ny4yMjk4NjQ1MDE5NTMxNiBMIDQ3MS40IDE5My4wMjk4NjQ1MDE5NTMxIEwgNDc3LjcgMTk3LjUyOTg2NDUwMTk1MzEgTCA0ODEuOSAyMDAuMjI5ODY0NTAxOTUzMTYgTCA0ODMuOSAyMDEuMTI5ODY0NTAxOTUzMTQgTCA0ODQuNSAyMDEuMTI5ODY0NTAxOTUzMTQgTCA0ODUuOCAyMDAuMDI5ODY0NTAxOTUzMSBMIDQ4Ny42IDE5Ni4wMjk4NjQ1MDE5NTMxIEwgNDg4LjggMTg5LjYyOTg2NDUwMTk1MzE0IEwgNDg5LjggMTgxLjMyOTg2NDUwMTk1MzEyIEwgNDkxIDE3MS42Mjk4NjQ1MDE5NTMxNCBMIDQ5MiAxNjEuNjI5ODY0NTAxOTUzMTQgTCA0OTMuNSAxNTEuNjI5ODY0NTAxOTUzMTQgTCA0OTUuMiAxNDMuMDI5ODY0NTAxOTUzMSBMIDQ5Ny40IDEzNS44Mjk4NjQ1MDE5NTMxMiBMIDQ5OS43IDEzMC41Mjk4NjQ1MDE5NTMxIEwgNTAyLjIgMTI3LjIyOTg2NDUwMTk1MzE2IEwgNTA0LjggMTI1LjUyOTg2NDUwMTk1MzExIEwgNTA5LjMgMTI2LjAyOTg2NDUwMTk1MzExIEwgNTExLjQgMTI3LjEyOTg2NDUwMTk1MzE0IEwgNTE2LjQgMTMwLjMyOTg2NDUwMTk1MzEyIEwgNTIzIDEzNS45Mjk4NjQ1MDE5NTMxNSBMIDUzMy44IDE0Ni4wMjk4NjQ1MDE5NTMxIEwgNTM3LjEgMTQ5LjcyOTg2NDUwMTk1MzE2IEwgNTQzLjkgMTU4LjAyOTg2NDUwMTk1MzEgTCA1NTEuMSAxNjYuNzI5ODY0NTAxOTUzMTYgTCA1NTguMSAxNzUuNjI5ODY0NTAxOTUzMTQgTCA1NjQuNiAxODQuNzI5ODY0NTAxOTUzMTYgTCA1NzEuNSAxOTMuMjI5ODY0NTAxOTUzMTYgTCA1NzguMyAyMDAuODI5ODY0NTAxOTUzMTIgTCA1ODcgMjExLjMyOTg2NDUwMTk1MzEyIEwgNTg5LjQgMjE0LjEyOTg2NDUwMTk1MzE0IEwgNTkzLjkgMjE5LjEyOTg2NDUwMTk1MzE0IEwgNTk3LjMgMjIzLjAyOTg2NDUwMTk1MzE3IEwgNjAwLjEgMjI2LjcyOTg2NDUwMTk1MzE2IEwgNjAxLjEgMjI4LjIyOTg2NDUwMTk1MzE2IEwgNjAxLjEgMjI4LjIyOTg2NDUwMTk1MzE2Ii8+PC9zdmc+","0.00","n8ktyey7","6","80","dzam122/default/20241227/081014296242789e6c93cd592289d9d7.jpeg,dzam122/default/20241227/fd9f9ba5a8978ce626c70063a6cfa412.jpeg","","","7,5,4,3","","","","北京市","北京市","东城区","110000","110100","110101","河南省郑州市金水区郑汴路126-2(凤凰台地铁站B口步行310米)","113.711533","34.747532","113.711533,34.747532","1","1","1","5","1","","1735299048","","1735298783","1735528312","0","2");



DROP TABLE cmf_technician_commission;

CREATE TABLE `cmf_technician_commission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '关联用户',
  `commission` varchar(255) DEFAULT NULL COMMENT '佣金比例',
  `min_amount` varchar(255) DEFAULT NULL COMMENT '最小金额',
  `max_amount` varchar(255) DEFAULT NULL COMMENT '最大金额',
  `list_order` int(255) DEFAULT '1000',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='技师佣金管理';




CREATE TABLE `cmf_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `a_image` varchar(255) DEFAULT NULL,
  `b_image` varchar(255) DEFAULT NULL,
  `images` text,
  `a_images` text,
  `b_images` text,
  `file` varchar(255) DEFAULT NULL,
  `a_file` varchar(255) DEFAULT NULL,
  `b_fine` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `a_video` varchar(255) DEFAULT NULL,
  `b_video` varchar(255) DEFAULT NULL,
  `content` text,
  `status` tinyint(4) DEFAULT '1' COMMENT '状态:1正常,2拉黑,3删除',
  `is_index` tinyint(4) DEFAULT '1' COMMENT '首页推荐:1是,2否',
  `type` tinyint(4) DEFAULT '1' COMMENT '类型:1普通商品,2抢购商品,3拼团商品',
  `is_pay` tinyint(4) DEFAULT '1' COMMENT '支付:1是,2否',
  `pay_type` tinyint(4) DEFAULT '1' COMMENT '支付类型:1微信,2余额,3支付宝',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

DROP TABLE cmf_theme;

CREATE TABLE `cmf_theme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后升级时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '模板状态,1:正在使用;0:未使用',
  `is_compiled` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否为已编译模板',
  `theme` varchar(20) NOT NULL DEFAULT '' COMMENT '主题目录名，用于主题的维一标识',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '主题名称',
  `version` varchar(20) NOT NULL DEFAULT '' COMMENT '主题版本号',
  `demo_url` varchar(50) NOT NULL DEFAULT '' COMMENT '演示地址，带协议',
  `thumbnail` varchar(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `author` varchar(20) NOT NULL DEFAULT '' COMMENT '主题作者',
  `author_url` varchar(50) NOT NULL DEFAULT '' COMMENT '作者网站链接',
  `lang` varchar(10) NOT NULL DEFAULT '' COMMENT '支持语言',
  `keywords` varchar(50) NOT NULL DEFAULT '' COMMENT '主题关键字',
  `description` varchar(100) NOT NULL DEFAULT '' COMMENT '主题描述',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='轮播图';

INSERT INTO cmf_theme VALUES("1","0","0","0","0","default","default","1.0.0","http://demo.thinkcmf.com","","ThinkCMF","http://www.thinkcmf.com","zh-cn","ThinkCMF默认模板","ThinkCMF默认模板");



DROP TABLE cmf_theme_file;

CREATE TABLE `cmf_theme_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_public` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否公共的模板文件',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `theme` varchar(20) NOT NULL DEFAULT '' COMMENT '模板名称',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '模板文件名',
  `action` varchar(50) NOT NULL DEFAULT '' COMMENT '操作',
  `file` varchar(50) NOT NULL DEFAULT '' COMMENT '模板文件，相对于模板根目录，如Portal/index.html',
  `description` varchar(100) NOT NULL DEFAULT '' COMMENT '模板文件描述',
  `more` text COMMENT '模板更多配置,用户自己后台设置的',
  `config_more` text COMMENT '模板更多配置,来源模板的配置文件',
  `draft_more` text COMMENT '模板更多配置,用户临时保存的配置',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='轮播图,图片';

INSERT INTO cmf_theme_file VALUES("1","0","5","default","首页","demo/Index/index","demo/index","首页模板文件","{\"vars\":{\"top_slide\":{\"title\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"admin\\/Slide\\/index\",\"multi\":false},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"tip\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"rule\":{\"require\":true}}},\"widgets\":{\"features\":{\"title\":\"\\u5feb\\u901f\\u4e86\\u89e3ThinkCMF\",\"display\":\"1\",\"vars\":{\"sub_title\":{\"title\":\"\\u526f\\u6807\\u9898\",\"value\":\"Quickly understand the ThinkCMF\",\"type\":\"text\",\"placeholder\":\"\\u8bf7\\u8f93\\u5165\\u526f\\u6807\\u9898\",\"tip\":\"\",\"rule\":{\"require\":true}},\"features\":{\"title\":\"\\u7279\\u6027\\u4ecb\\u7ecd\",\"value\":[{\"title\":\"MVC\\u5206\\u5c42\\u6a21\\u5f0f\",\"icon\":\"bars\",\"content\":\"\\u4f7f\\u7528MVC\\u5e94\\u7528\\u7a0b\\u5e8f\\u88ab\\u5206\\u6210\\u4e09\\u4e2a\\u6838\\u5fc3\\u90e8\\u4ef6\\uff1a\\u6a21\\u578b\\uff08M\\uff09\\u3001\\u89c6\\u56fe\\uff08V\\uff09\\u3001\\u63a7\\u5236\\u5668\\uff08C\\uff09\\uff0c\\u4ed6\\u4e0d\\u662f\\u4e00\\u4e2a\\u65b0\\u7684\\u6982\\u5ff5\\uff0c\\u53ea\\u662fThinkCMF\\u5c06\\u5176\\u53d1\\u6325\\u5230\\u4e86\\u6781\\u81f4\\u3002\"},{\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"group\",\"content\":\"ThinkCMF\\u5185\\u7f6e\\u4e86\\u7075\\u6d3b\\u7684\\u7528\\u6237\\u7ba1\\u7406\\u65b9\\u5f0f\\uff0c\\u5e76\\u53ef\\u76f4\\u63a5\\u4e0e\\u7b2c\\u4e09\\u65b9\\u7ad9\\u70b9\\u8fdb\\u884c\\u4e92\\u8054\\u4e92\\u901a\\uff0c\\u5982\\u679c\\u4f60\\u613f\\u610f\\u751a\\u81f3\\u53ef\\u4ee5\\u5bf9\\u5355\\u4e2a\\u7528\\u6237\\u6216\\u7fa4\\u4f53\\u7528\\u6237\\u7684\\u884c\\u4e3a\\u8fdb\\u884c\\u8bb0\\u5f55\\u53ca\\u5206\\u4eab\\uff0c\\u4e3a\\u60a8\\u7684\\u8fd0\\u8425\\u51b3\\u7b56\\u63d0\\u4f9b\\u6709\\u6548\\u53c2\\u8003\\u6570\\u636e\\u3002\"},{\"title\":\"\\u4e91\\u7aef\\u90e8\\u7f72\",\"icon\":\"cloud\",\"content\":\"\\u901a\\u8fc7\\u9a71\\u52a8\\u7684\\u65b9\\u5f0f\\u53ef\\u4ee5\\u8f7b\\u677e\\u652f\\u6301\\u4e91\\u5e73\\u53f0\\u7684\\u90e8\\u7f72\\uff0c\\u8ba9\\u4f60\\u7684\\u7f51\\u7ad9\\u65e0\\u7f1d\\u8fc1\\u79fb\\uff0c\\u5185\\u7f6e\\u5df2\\u7ecf\\u652f\\u6301SAE\\u3001BAE\\uff0c\\u6b63\\u5f0f\\u7248\\u5c06\\u5bf9\\u4e91\\u7aef\\u90e8\\u7f72\\u8fdb\\u884c\\u8fdb\\u4e00\\u6b65\\u4f18\\u5316\\u3002\"},{\"title\":\"\\u5b89\\u5168\\u7b56\\u7565\",\"icon\":\"heart\",\"content\":\"\\u63d0\\u4f9b\\u7684\\u7a33\\u5065\\u7684\\u5b89\\u5168\\u7b56\\u7565\\uff0c\\u5305\\u62ec\\u5907\\u4efd\\u6062\\u590d\\uff0c\\u5bb9\\u9519\\uff0c\\u9632\\u6cbb\\u6076\\u610f\\u653b\\u51fb\\u767b\\u9646\\uff0c\\u7f51\\u9875\\u9632\\u7be1\\u6539\\u7b49\\u591a\\u9879\\u5b89\\u5168\\u7ba1\\u7406\\u529f\\u80fd\\uff0c\\u4fdd\\u8bc1\\u7cfb\\u7edf\\u5b89\\u5168\\uff0c\\u53ef\\u9760\\uff0c\\u7a33\\u5b9a\\u7684\\u8fd0\\u884c\\u3002\"},{\"title\":\"\\u5e94\\u7528\\u6a21\\u5757\\u5316\",\"icon\":\"cubes\",\"content\":\"\\u63d0\\u51fa\\u5168\\u65b0\\u7684\\u5e94\\u7528\\u6a21\\u5f0f\\u8fdb\\u884c\\u6269\\u5c55\\uff0c\\u4e0d\\u7ba1\\u662f\\u4f60\\u5f00\\u53d1\\u4e00\\u4e2a\\u5c0f\\u529f\\u80fd\\u8fd8\\u662f\\u4e00\\u4e2a\\u5168\\u65b0\\u7684\\u7ad9\\u70b9\\uff0c\\u5728ThinkCMF\\u4e2d\\u4f60\\u53ea\\u662f\\u589e\\u52a0\\u4e86\\u4e00\\u4e2aAPP\\uff0c\\u6bcf\\u4e2a\\u72ec\\u7acb\\u8fd0\\u884c\\u4e92\\u4e0d\\u5f71\\u54cd\\uff0c\\u4fbf\\u4e8e\\u7075\\u6d3b\\u6269\\u5c55\\u548c\\u4e8c\\u6b21\\u5f00\\u53d1\\u3002\"},{\"title\":\"\\u514d\\u8d39\\u5f00\\u6e90\",\"icon\":\"certificate\",\"content\":\"\\u4ee3\\u7801\\u9075\\u5faaApache2\\u5f00\\u6e90\\u534f\\u8bae\\uff0c\\u514d\\u8d39\\u4f7f\\u7528\\uff0c\\u5bf9\\u5546\\u4e1a\\u7528\\u6237\\u4e5f\\u65e0\\u4efb\\u4f55\\u9650\\u5236\\u3002\"}],\"type\":\"array\",\"item\":{\"title\":{\"title\":\"\\u6807\\u9898\",\"value\":\"\",\"type\":\"text\",\"rule\":{\"require\":true}},\"icon\":{\"title\":\"\\u56fe\\u6807\",\"value\":\"\",\"type\":\"text\"},\"content\":{\"title\":\"\\u63cf\\u8ff0\",\"value\":\"\",\"type\":\"textarea\"}},\"tip\":\"\"}}},\"last_news\":{\"title\":\"\\u6700\\u65b0\\u8d44\\u8baf\",\"display\":\"1\",\"vars\":{\"last_news_category_id\":{\"title\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"portal\\/Category\\/index\",\"multi\":true},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b\",\"tip\":\"\",\"rule\":{\"require\":true}}}}}}","{\"vars\":{\"top_slide\":{\"title\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"admin\\/Slide\\/index\",\"multi\":false},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"tip\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"rule\":{\"require\":true}}},\"widgets\":{\"features\":{\"title\":\"\\u5feb\\u901f\\u4e86\\u89e3ThinkCMF\",\"display\":\"1\",\"vars\":{\"sub_title\":{\"title\":\"\\u526f\\u6807\\u9898\",\"value\":\"Quickly understand the ThinkCMF\",\"type\":\"text\",\"placeholder\":\"\\u8bf7\\u8f93\\u5165\\u526f\\u6807\\u9898\",\"tip\":\"\",\"rule\":{\"require\":true}},\"features\":{\"title\":\"\\u7279\\u6027\\u4ecb\\u7ecd\",\"value\":[{\"title\":\"MVC\\u5206\\u5c42\\u6a21\\u5f0f\",\"icon\":\"bars\",\"content\":\"\\u4f7f\\u7528MVC\\u5e94\\u7528\\u7a0b\\u5e8f\\u88ab\\u5206\\u6210\\u4e09\\u4e2a\\u6838\\u5fc3\\u90e8\\u4ef6\\uff1a\\u6a21\\u578b\\uff08M\\uff09\\u3001\\u89c6\\u56fe\\uff08V\\uff09\\u3001\\u63a7\\u5236\\u5668\\uff08C\\uff09\\uff0c\\u4ed6\\u4e0d\\u662f\\u4e00\\u4e2a\\u65b0\\u7684\\u6982\\u5ff5\\uff0c\\u53ea\\u662fThinkCMF\\u5c06\\u5176\\u53d1\\u6325\\u5230\\u4e86\\u6781\\u81f4\\u3002\"},{\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"group\",\"content\":\"ThinkCMF\\u5185\\u7f6e\\u4e86\\u7075\\u6d3b\\u7684\\u7528\\u6237\\u7ba1\\u7406\\u65b9\\u5f0f\\uff0c\\u5e76\\u53ef\\u76f4\\u63a5\\u4e0e\\u7b2c\\u4e09\\u65b9\\u7ad9\\u70b9\\u8fdb\\u884c\\u4e92\\u8054\\u4e92\\u901a\\uff0c\\u5982\\u679c\\u4f60\\u613f\\u610f\\u751a\\u81f3\\u53ef\\u4ee5\\u5bf9\\u5355\\u4e2a\\u7528\\u6237\\u6216\\u7fa4\\u4f53\\u7528\\u6237\\u7684\\u884c\\u4e3a\\u8fdb\\u884c\\u8bb0\\u5f55\\u53ca\\u5206\\u4eab\\uff0c\\u4e3a\\u60a8\\u7684\\u8fd0\\u8425\\u51b3\\u7b56\\u63d0\\u4f9b\\u6709\\u6548\\u53c2\\u8003\\u6570\\u636e\\u3002\"},{\"title\":\"\\u4e91\\u7aef\\u90e8\\u7f72\",\"icon\":\"cloud\",\"content\":\"\\u901a\\u8fc7\\u9a71\\u52a8\\u7684\\u65b9\\u5f0f\\u53ef\\u4ee5\\u8f7b\\u677e\\u652f\\u6301\\u4e91\\u5e73\\u53f0\\u7684\\u90e8\\u7f72\\uff0c\\u8ba9\\u4f60\\u7684\\u7f51\\u7ad9\\u65e0\\u7f1d\\u8fc1\\u79fb\\uff0c\\u5185\\u7f6e\\u5df2\\u7ecf\\u652f\\u6301SAE\\u3001BAE\\uff0c\\u6b63\\u5f0f\\u7248\\u5c06\\u5bf9\\u4e91\\u7aef\\u90e8\\u7f72\\u8fdb\\u884c\\u8fdb\\u4e00\\u6b65\\u4f18\\u5316\\u3002\"},{\"title\":\"\\u5b89\\u5168\\u7b56\\u7565\",\"icon\":\"heart\",\"content\":\"\\u63d0\\u4f9b\\u7684\\u7a33\\u5065\\u7684\\u5b89\\u5168\\u7b56\\u7565\\uff0c\\u5305\\u62ec\\u5907\\u4efd\\u6062\\u590d\\uff0c\\u5bb9\\u9519\\uff0c\\u9632\\u6cbb\\u6076\\u610f\\u653b\\u51fb\\u767b\\u9646\\uff0c\\u7f51\\u9875\\u9632\\u7be1\\u6539\\u7b49\\u591a\\u9879\\u5b89\\u5168\\u7ba1\\u7406\\u529f\\u80fd\\uff0c\\u4fdd\\u8bc1\\u7cfb\\u7edf\\u5b89\\u5168\\uff0c\\u53ef\\u9760\\uff0c\\u7a33\\u5b9a\\u7684\\u8fd0\\u884c\\u3002\"},{\"title\":\"\\u5e94\\u7528\\u6a21\\u5757\\u5316\",\"icon\":\"cubes\",\"content\":\"\\u63d0\\u51fa\\u5168\\u65b0\\u7684\\u5e94\\u7528\\u6a21\\u5f0f\\u8fdb\\u884c\\u6269\\u5c55\\uff0c\\u4e0d\\u7ba1\\u662f\\u4f60\\u5f00\\u53d1\\u4e00\\u4e2a\\u5c0f\\u529f\\u80fd\\u8fd8\\u662f\\u4e00\\u4e2a\\u5168\\u65b0\\u7684\\u7ad9\\u70b9\\uff0c\\u5728ThinkCMF\\u4e2d\\u4f60\\u53ea\\u662f\\u589e\\u52a0\\u4e86\\u4e00\\u4e2aAPP\\uff0c\\u6bcf\\u4e2a\\u72ec\\u7acb\\u8fd0\\u884c\\u4e92\\u4e0d\\u5f71\\u54cd\\uff0c\\u4fbf\\u4e8e\\u7075\\u6d3b\\u6269\\u5c55\\u548c\\u4e8c\\u6b21\\u5f00\\u53d1\\u3002\"},{\"title\":\"\\u514d\\u8d39\\u5f00\\u6e90\",\"icon\":\"certificate\",\"content\":\"\\u4ee3\\u7801\\u9075\\u5faaApache2\\u5f00\\u6e90\\u534f\\u8bae\\uff0c\\u514d\\u8d39\\u4f7f\\u7528\\uff0c\\u5bf9\\u5546\\u4e1a\\u7528\\u6237\\u4e5f\\u65e0\\u4efb\\u4f55\\u9650\\u5236\\u3002\"}],\"type\":\"array\",\"item\":{\"title\":{\"title\":\"\\u6807\\u9898\",\"value\":\"\",\"type\":\"text\",\"rule\":{\"require\":true}},\"icon\":{\"title\":\"\\u56fe\\u6807\",\"value\":\"\",\"type\":\"text\"},\"content\":{\"title\":\"\\u63cf\\u8ff0\",\"value\":\"\",\"type\":\"textarea\"}},\"tip\":\"\"}}},\"last_news\":{\"title\":\"\\u6700\\u65b0\\u8d44\\u8baf\",\"display\":\"1\",\"vars\":{\"last_news_category_id\":{\"title\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"portal\\/Category\\/index\",\"multi\":true},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b\",\"tip\":\"\",\"rule\":{\"require\":true}}}}}}","");
INSERT INTO cmf_theme_file VALUES("2","0","5","default","首页","portal/Index/index","portal/index","首页模板文件","{\"vars\":{\"top_slide\":{\"title\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"admin\\/Slide\\/index\",\"multi\":false},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"tip\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"rule\":{\"require\":true}}},\"widgets\":{\"features\":{\"title\":\"\\u5feb\\u901f\\u4e86\\u89e3ThinkCMF\",\"display\":\"1\",\"vars\":{\"sub_title\":{\"title\":\"\\u526f\\u6807\\u9898\",\"value\":\"Quickly understand the ThinkCMF\",\"type\":\"text\",\"placeholder\":\"\\u8bf7\\u8f93\\u5165\\u526f\\u6807\\u9898\",\"tip\":\"\",\"rule\":{\"require\":true}},\"features\":{\"title\":\"\\u7279\\u6027\\u4ecb\\u7ecd\",\"value\":[{\"title\":\"MVC\\u5206\\u5c42\\u6a21\\u5f0f\",\"icon\":\"bars\",\"content\":\"\\u4f7f\\u7528MVC\\u5e94\\u7528\\u7a0b\\u5e8f\\u88ab\\u5206\\u6210\\u4e09\\u4e2a\\u6838\\u5fc3\\u90e8\\u4ef6\\uff1a\\u6a21\\u578b\\uff08M\\uff09\\u3001\\u89c6\\u56fe\\uff08V\\uff09\\u3001\\u63a7\\u5236\\u5668\\uff08C\\uff09\\uff0c\\u4ed6\\u4e0d\\u662f\\u4e00\\u4e2a\\u65b0\\u7684\\u6982\\u5ff5\\uff0c\\u53ea\\u662fThinkCMF\\u5c06\\u5176\\u53d1\\u6325\\u5230\\u4e86\\u6781\\u81f4\\u3002\"},{\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"group\",\"content\":\"ThinkCMF\\u5185\\u7f6e\\u4e86\\u7075\\u6d3b\\u7684\\u7528\\u6237\\u7ba1\\u7406\\u65b9\\u5f0f\\uff0c\\u5e76\\u53ef\\u76f4\\u63a5\\u4e0e\\u7b2c\\u4e09\\u65b9\\u7ad9\\u70b9\\u8fdb\\u884c\\u4e92\\u8054\\u4e92\\u901a\\uff0c\\u5982\\u679c\\u4f60\\u613f\\u610f\\u751a\\u81f3\\u53ef\\u4ee5\\u5bf9\\u5355\\u4e2a\\u7528\\u6237\\u6216\\u7fa4\\u4f53\\u7528\\u6237\\u7684\\u884c\\u4e3a\\u8fdb\\u884c\\u8bb0\\u5f55\\u53ca\\u5206\\u4eab\\uff0c\\u4e3a\\u60a8\\u7684\\u8fd0\\u8425\\u51b3\\u7b56\\u63d0\\u4f9b\\u6709\\u6548\\u53c2\\u8003\\u6570\\u636e\\u3002\"},{\"title\":\"\\u4e91\\u7aef\\u90e8\\u7f72\",\"icon\":\"cloud\",\"content\":\"\\u901a\\u8fc7\\u9a71\\u52a8\\u7684\\u65b9\\u5f0f\\u53ef\\u4ee5\\u8f7b\\u677e\\u652f\\u6301\\u4e91\\u5e73\\u53f0\\u7684\\u90e8\\u7f72\\uff0c\\u8ba9\\u4f60\\u7684\\u7f51\\u7ad9\\u65e0\\u7f1d\\u8fc1\\u79fb\\uff0c\\u5185\\u7f6e\\u5df2\\u7ecf\\u652f\\u6301SAE\\u3001BAE\\uff0c\\u6b63\\u5f0f\\u7248\\u5c06\\u5bf9\\u4e91\\u7aef\\u90e8\\u7f72\\u8fdb\\u884c\\u8fdb\\u4e00\\u6b65\\u4f18\\u5316\\u3002\"},{\"title\":\"\\u5b89\\u5168\\u7b56\\u7565\",\"icon\":\"heart\",\"content\":\"\\u63d0\\u4f9b\\u7684\\u7a33\\u5065\\u7684\\u5b89\\u5168\\u7b56\\u7565\\uff0c\\u5305\\u62ec\\u5907\\u4efd\\u6062\\u590d\\uff0c\\u5bb9\\u9519\\uff0c\\u9632\\u6cbb\\u6076\\u610f\\u653b\\u51fb\\u767b\\u9646\\uff0c\\u7f51\\u9875\\u9632\\u7be1\\u6539\\u7b49\\u591a\\u9879\\u5b89\\u5168\\u7ba1\\u7406\\u529f\\u80fd\\uff0c\\u4fdd\\u8bc1\\u7cfb\\u7edf\\u5b89\\u5168\\uff0c\\u53ef\\u9760\\uff0c\\u7a33\\u5b9a\\u7684\\u8fd0\\u884c\\u3002\"},{\"title\":\"\\u5e94\\u7528\\u6a21\\u5757\\u5316\",\"icon\":\"cubes\",\"content\":\"\\u63d0\\u51fa\\u5168\\u65b0\\u7684\\u5e94\\u7528\\u6a21\\u5f0f\\u8fdb\\u884c\\u6269\\u5c55\\uff0c\\u4e0d\\u7ba1\\u662f\\u4f60\\u5f00\\u53d1\\u4e00\\u4e2a\\u5c0f\\u529f\\u80fd\\u8fd8\\u662f\\u4e00\\u4e2a\\u5168\\u65b0\\u7684\\u7ad9\\u70b9\\uff0c\\u5728ThinkCMF\\u4e2d\\u4f60\\u53ea\\u662f\\u589e\\u52a0\\u4e86\\u4e00\\u4e2aAPP\\uff0c\\u6bcf\\u4e2a\\u72ec\\u7acb\\u8fd0\\u884c\\u4e92\\u4e0d\\u5f71\\u54cd\\uff0c\\u4fbf\\u4e8e\\u7075\\u6d3b\\u6269\\u5c55\\u548c\\u4e8c\\u6b21\\u5f00\\u53d1\\u3002\"},{\"title\":\"\\u514d\\u8d39\\u5f00\\u6e90\",\"icon\":\"certificate\",\"content\":\"\\u4ee3\\u7801\\u9075\\u5faaApache2\\u5f00\\u6e90\\u534f\\u8bae\\uff0c\\u514d\\u8d39\\u4f7f\\u7528\\uff0c\\u5bf9\\u5546\\u4e1a\\u7528\\u6237\\u4e5f\\u65e0\\u4efb\\u4f55\\u9650\\u5236\\u3002\"}],\"type\":\"array\",\"item\":{\"title\":{\"title\":\"\\u6807\\u9898\",\"value\":\"\",\"type\":\"text\",\"rule\":{\"require\":true}},\"icon\":{\"title\":\"\\u56fe\\u6807\",\"value\":\"\",\"type\":\"text\"},\"content\":{\"title\":\"\\u63cf\\u8ff0\",\"value\":\"\",\"type\":\"textarea\"}},\"tip\":\"\"}}},\"last_news\":{\"title\":\"\\u6700\\u65b0\\u8d44\\u8baf\",\"display\":\"1\",\"vars\":{\"last_news_category_id\":{\"title\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"portal\\/Category\\/index\",\"multi\":true},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b\",\"tip\":\"\",\"rule\":{\"require\":true}}}}}}","{\"vars\":{\"top_slide\":{\"title\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"admin\\/Slide\\/index\",\"multi\":false},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"tip\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"rule\":{\"require\":true}}},\"widgets\":{\"features\":{\"title\":\"\\u5feb\\u901f\\u4e86\\u89e3ThinkCMF\",\"display\":\"1\",\"vars\":{\"sub_title\":{\"title\":\"\\u526f\\u6807\\u9898\",\"value\":\"Quickly understand the ThinkCMF\",\"type\":\"text\",\"placeholder\":\"\\u8bf7\\u8f93\\u5165\\u526f\\u6807\\u9898\",\"tip\":\"\",\"rule\":{\"require\":true}},\"features\":{\"title\":\"\\u7279\\u6027\\u4ecb\\u7ecd\",\"value\":[{\"title\":\"MVC\\u5206\\u5c42\\u6a21\\u5f0f\",\"icon\":\"bars\",\"content\":\"\\u4f7f\\u7528MVC\\u5e94\\u7528\\u7a0b\\u5e8f\\u88ab\\u5206\\u6210\\u4e09\\u4e2a\\u6838\\u5fc3\\u90e8\\u4ef6\\uff1a\\u6a21\\u578b\\uff08M\\uff09\\u3001\\u89c6\\u56fe\\uff08V\\uff09\\u3001\\u63a7\\u5236\\u5668\\uff08C\\uff09\\uff0c\\u4ed6\\u4e0d\\u662f\\u4e00\\u4e2a\\u65b0\\u7684\\u6982\\u5ff5\\uff0c\\u53ea\\u662fThinkCMF\\u5c06\\u5176\\u53d1\\u6325\\u5230\\u4e86\\u6781\\u81f4\\u3002\"},{\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"group\",\"content\":\"ThinkCMF\\u5185\\u7f6e\\u4e86\\u7075\\u6d3b\\u7684\\u7528\\u6237\\u7ba1\\u7406\\u65b9\\u5f0f\\uff0c\\u5e76\\u53ef\\u76f4\\u63a5\\u4e0e\\u7b2c\\u4e09\\u65b9\\u7ad9\\u70b9\\u8fdb\\u884c\\u4e92\\u8054\\u4e92\\u901a\\uff0c\\u5982\\u679c\\u4f60\\u613f\\u610f\\u751a\\u81f3\\u53ef\\u4ee5\\u5bf9\\u5355\\u4e2a\\u7528\\u6237\\u6216\\u7fa4\\u4f53\\u7528\\u6237\\u7684\\u884c\\u4e3a\\u8fdb\\u884c\\u8bb0\\u5f55\\u53ca\\u5206\\u4eab\\uff0c\\u4e3a\\u60a8\\u7684\\u8fd0\\u8425\\u51b3\\u7b56\\u63d0\\u4f9b\\u6709\\u6548\\u53c2\\u8003\\u6570\\u636e\\u3002\"},{\"title\":\"\\u4e91\\u7aef\\u90e8\\u7f72\",\"icon\":\"cloud\",\"content\":\"\\u901a\\u8fc7\\u9a71\\u52a8\\u7684\\u65b9\\u5f0f\\u53ef\\u4ee5\\u8f7b\\u677e\\u652f\\u6301\\u4e91\\u5e73\\u53f0\\u7684\\u90e8\\u7f72\\uff0c\\u8ba9\\u4f60\\u7684\\u7f51\\u7ad9\\u65e0\\u7f1d\\u8fc1\\u79fb\\uff0c\\u5185\\u7f6e\\u5df2\\u7ecf\\u652f\\u6301SAE\\u3001BAE\\uff0c\\u6b63\\u5f0f\\u7248\\u5c06\\u5bf9\\u4e91\\u7aef\\u90e8\\u7f72\\u8fdb\\u884c\\u8fdb\\u4e00\\u6b65\\u4f18\\u5316\\u3002\"},{\"title\":\"\\u5b89\\u5168\\u7b56\\u7565\",\"icon\":\"heart\",\"content\":\"\\u63d0\\u4f9b\\u7684\\u7a33\\u5065\\u7684\\u5b89\\u5168\\u7b56\\u7565\\uff0c\\u5305\\u62ec\\u5907\\u4efd\\u6062\\u590d\\uff0c\\u5bb9\\u9519\\uff0c\\u9632\\u6cbb\\u6076\\u610f\\u653b\\u51fb\\u767b\\u9646\\uff0c\\u7f51\\u9875\\u9632\\u7be1\\u6539\\u7b49\\u591a\\u9879\\u5b89\\u5168\\u7ba1\\u7406\\u529f\\u80fd\\uff0c\\u4fdd\\u8bc1\\u7cfb\\u7edf\\u5b89\\u5168\\uff0c\\u53ef\\u9760\\uff0c\\u7a33\\u5b9a\\u7684\\u8fd0\\u884c\\u3002\"},{\"title\":\"\\u5e94\\u7528\\u6a21\\u5757\\u5316\",\"icon\":\"cubes\",\"content\":\"\\u63d0\\u51fa\\u5168\\u65b0\\u7684\\u5e94\\u7528\\u6a21\\u5f0f\\u8fdb\\u884c\\u6269\\u5c55\\uff0c\\u4e0d\\u7ba1\\u662f\\u4f60\\u5f00\\u53d1\\u4e00\\u4e2a\\u5c0f\\u529f\\u80fd\\u8fd8\\u662f\\u4e00\\u4e2a\\u5168\\u65b0\\u7684\\u7ad9\\u70b9\\uff0c\\u5728ThinkCMF\\u4e2d\\u4f60\\u53ea\\u662f\\u589e\\u52a0\\u4e86\\u4e00\\u4e2aAPP\\uff0c\\u6bcf\\u4e2a\\u72ec\\u7acb\\u8fd0\\u884c\\u4e92\\u4e0d\\u5f71\\u54cd\\uff0c\\u4fbf\\u4e8e\\u7075\\u6d3b\\u6269\\u5c55\\u548c\\u4e8c\\u6b21\\u5f00\\u53d1\\u3002\"},{\"title\":\"\\u514d\\u8d39\\u5f00\\u6e90\",\"icon\":\"certificate\",\"content\":\"\\u4ee3\\u7801\\u9075\\u5faaApache2\\u5f00\\u6e90\\u534f\\u8bae\\uff0c\\u514d\\u8d39\\u4f7f\\u7528\\uff0c\\u5bf9\\u5546\\u4e1a\\u7528\\u6237\\u4e5f\\u65e0\\u4efb\\u4f55\\u9650\\u5236\\u3002\"}],\"type\":\"array\",\"item\":{\"title\":{\"title\":\"\\u6807\\u9898\",\"value\":\"\",\"type\":\"text\",\"rule\":{\"require\":true}},\"icon\":{\"title\":\"\\u56fe\\u6807\",\"value\":\"\",\"type\":\"text\"},\"content\":{\"title\":\"\\u63cf\\u8ff0\",\"value\":\"\",\"type\":\"textarea\"}},\"tip\":\"\"}}},\"last_news\":{\"title\":\"\\u6700\\u65b0\\u8d44\\u8baf\",\"display\":\"1\",\"vars\":{\"last_news_category_id\":{\"title\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"portal\\/Category\\/index\",\"multi\":true},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b\",\"tip\":\"\",\"rule\":{\"require\":true}}}}}}","");



DROP TABLE cmf_user;

CREATE TABLE `cmf_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '用户类型;1:admin;2:会员',
  `sex` tinyint(2) NOT NULL DEFAULT '0' COMMENT '性别;0:保密,1:男,2:女',
  `birthday` int(11) NOT NULL DEFAULT '0' COMMENT '生日',
  `last_login_time` int(11) NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `score` int(11) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `coin` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '金币',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '注册时间',
  `user_status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '用户状态;0:禁用,1:正常,2:未验证',
  `user_login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `user_pass` varchar(64) NOT NULL DEFAULT '' COMMENT '登录密码;cmf_password加密',
  `user_nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户昵称',
  `user_email` varchar(100) NOT NULL DEFAULT '' COMMENT '用户登录邮箱',
  `user_url` varchar(100) NOT NULL DEFAULT '' COMMENT '用户个人网址',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '用户头像',
  `signature` varchar(255) NOT NULL DEFAULT '' COMMENT '个性签名',
  `last_login_ip` varchar(15) NOT NULL DEFAULT '' COMMENT '最后登录ip',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '' COMMENT '激活码',
  `mobile` varchar(20) NOT NULL DEFAULT '' COMMENT '中国手机不带国家代码，国际手机号格式为：国家代码-手机号',
  `more` text COMMENT '扩展属性',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `user_login` (`user_login`) USING BTREE,
  KEY `user_nickname` (`user_nickname`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

INSERT INTO cmf_user VALUES("1","1","0","0","1744092210","0","0","0.00","1660558068","1","admin","###7a83c4a197d689babb621303f7f65c07","admin","admin@gmail.com","","","","123.14.163.167","","","");



DROP TABLE cmf_user_login_attempt;

CREATE TABLE `cmf_user_login_attempt` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `login_attempts` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '尝试次数',
  `attempt_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '尝试登录时间',
  `locked_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '锁定时间',
  `ip` varchar(15) NOT NULL DEFAULT '' COMMENT '用户 ip',
  `account` varchar(100) NOT NULL DEFAULT '' COMMENT '用户账号,手机号,邮箱或用户名',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户登录尝试表';




DROP TABLE cmf_user_token;

CREATE TABLE `cmf_user_token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户id',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT ' 过期时间',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `token` varchar(64) NOT NULL DEFAULT '' COMMENT 'token',
  `device_type` varchar(10) NOT NULL DEFAULT '' COMMENT '设备类型;mobile,android,iphone,ipad,web,pc,mac,wxapp',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='用户客户端登录 token 表';

INSERT INTO cmf_user_token VALUES("1","1","1756968138","1741416138","249c43ca14f34506625979d87c5ef84351eb9b0418692f6839c19b62eecd4b21","web");



DROP TABLE cmf_verification_code;

CREATE TABLE `cmf_verification_code` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '表id',
  `count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '当天已经发送成功的次数',
  `send_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后发送成功时间',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '验证码过期时间',
  `code` varchar(8) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '最后发送成功的验证码',
  `account` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '手机号或者邮箱',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='手机邮箱数字验证码表';

INSERT INTO cmf_verification_code VALUES("1","1","1725093648","1725095448","107952","5e-18");
INSERT INTO cmf_verification_code VALUES("2","1","1727685468","1727687268","284079","18239446258");
INSERT INTO cmf_verification_code VALUES("3","1","1725612921","1725614721","983618","18582300163");
INSERT INTO cmf_verification_code VALUES("4","1","1725521398","1725523198","874819","1856235487");
INSERT INTO cmf_verification_code VALUES("5","1","1725527514","1725529314","519121","18239446256");
INSERT INTO cmf_verification_code VALUES("6","1","1726735301","1726737101","521342","15537561053");
INSERT INTO cmf_verification_code VALUES("7","1","1725602657","1725604457","893045","18103908056");
INSERT INTO cmf_verification_code VALUES("8","1","1725681665","1725683465","785479","18633550607");
INSERT INTO cmf_verification_code VALUES("9","2","1726565956","1726567756","417714","15038853637");
INSERT INTO cmf_verification_code VALUES("10","2","1728400124","1728401924","713727","18630578667");
INSERT INTO cmf_verification_code VALUES("11","1","1729313733","1729315533","340693","18396929049");
INSERT INTO cmf_verification_code VALUES("12","1","1729423759","1729425559","382535","18330369063");
INSERT INTO cmf_verification_code VALUES("13","2","1729604497","1729606297","736052","18630398550");



